package com.sajangnim.settlement;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context newBase) {
        android.content.res.Configuration config =
            new android.content.res.Configuration(newBase.getResources().getConfiguration());
        config.fontScale = 1.0f;
        android.content.Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }



    private static final int FILE_CHOOSER_REQUEST = 1001;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);

        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(
                    0,
                    insets.getSystemWindowInsetTop(),
                    0,
                    insets.getSystemWindowInsetBottom()
            );
            return insets;
        });

        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {

                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }

                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);

                // 일부 Android 파일 앱/제조사 파일 선택기는 .json 파일을
                // application/json이 아니라 text/plain 또는
                // application/octet-stream으로 분류하기도 합니다.
                // 한 MIME 타입으로 제한하면 정상 백업 파일이 목록에서 사라질 수 있어
                // 파일 선택 화면에서는 넓게 허용하고, 실제 JSON 검증은 앱에서 수행합니다.
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                        "application/json",
                        "text/json",
                        "text/plain",
                        "application/octet-stream"
                });

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    // ACTION_OPEN_DOCUMENT를 지원하지 않는 파일 앱 대비
                    try {
                        Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType("*/*");
                        startActivityForResult(fallback, FILE_CHOOSER_REQUEST);
                        return true;
                    } catch (Exception ignored) {
                        MainActivity.this.filePathCallback = null;
                        return false;
                    }
                }
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> finish());
        }

        @JavascriptInterface
        public void setSystemBarsTheme(boolean dark) {
            runOnUiThread(() -> {
                getWindow().setStatusBarColor(Color.parseColor(dark ? "#111827" : "#24364B"));
                getWindow().setNavigationBarColor(Color.parseColor(dark ? "#111827" : "#FFFFFF"));

                View decor = getWindow().getDecorView();
                int flags = decor.getSystemUiVisibility();

                // Keep status-bar icons white in both themes.
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;

                // Bottom navigation icons still follow the selected theme.
                if (dark) {
                    flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                } else {
                    flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }

                decor.setSystemUiVisibility(flags);
            });
        }
        @JavascriptInterface
        public void saveBackup(String json, String fileName) {
            runOnUiThread(() -> {
                try {
                    String safeName = (fileName == null || fileName.trim().isEmpty())
                            ? "사장님정산_백업.json"
                            : fileName;

                    ContentResolver resolver = getContentResolver();
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                    Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("다운로드 파일을 만들 수 없습니다.");

                    try (OutputStream out = resolver.openOutputStream(uri)) {
                        if (out == null) throw new Exception("파일을 열 수 없습니다.");
                        out.write(json.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                    }

                    webView.evaluateJavascript("showBackupToast('백업 파일을 다운로드 폴더에 저장했어요.')", null);
                } catch (Exception e) {
                    webView.evaluateJavascript("showBackupToast('백업 저장에 실패했어요.')", null);
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;

            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }

            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }

        webView.evaluateJavascript(
                "(function(){return (typeof isExitConfirmOpen==='function' && isExitConfirmOpen()) ? '1' : '0';})()",
                value -> {
                    if ("\"1\"".equals(value)) {
                        webView.evaluateJavascript("closeExitConfirm()", null);
                    } else if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        webView.evaluateJavascript("showExitConfirm()", null);
                    }
                }
        );
    }
}
