# 1.0.4 TEST ADS

- Google Mobile Ads SDK: 25.4.0
- Google sample AdMob App ID (test only): ca-app-pub-3940256099942544~3347511713
- Google Android anchored adaptive banner test unit: ca-app-pub-3940256099942544/9214589741
- Banner location: native bottom anchored area below the WebView
- This build intentionally does NOT use the owner's live AdMob banner unit.
- Before production release, replace the sample App ID and test ad unit ID with the real AdMob IDs and update Play Console declarations/privacy disclosures as required.


## v63 layout fix
- Removed duplicate native top status-bar inset that caused a white blank strip.
- Kept bottom system inset so the anchored adaptive test banner stays above navigation controls.
- Test banner only. Do not upload this test-ad build to production.
