# v77 Home header match

- 홈 상단바를 설정 화면 상단바와 같은 기준 높이/상단 여백으로 조정
- 홈 제목이 너무 아래로 내려오던 문제 수정
- 설정 버튼도 상단바 수직 중앙으로 정렬
- 요약카드/목표매출/달력 구조는 그대로 유지
- v76의 뒤로가기 수정 유지
- AD_ID / R8 / AndroidX / 광고 / UMP 유지
- versionCode 17
- versionName 1.0.11
