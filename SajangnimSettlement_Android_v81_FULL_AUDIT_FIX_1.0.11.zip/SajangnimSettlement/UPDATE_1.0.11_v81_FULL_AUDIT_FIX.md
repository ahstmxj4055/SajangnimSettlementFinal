사장님 정산 v81 정적 코드 점검 결과

점검 범위
- AndroidManifest.xml
- app/build.gradle.kts
- MainActivity.java
- index.html 전체 HTML/CSS/JavaScript
- 백업/복원 구조
- 상세정산/빠른정산 연동
- 직원/일일알바
- 목표매출
- 뒤로가기/History API
- AdMob/UMP
- Android 15/16 safe-area
- 버전 표시

확인 결과
1. JavaScript 문법 검사: 통과
2. HTML 중복 id: 없음
3. 중복 JavaScript 함수 선언: 없음
4. 주요 onclick/onchange 함수 누락: 없음
5. package / targetSdk / AD_ID / AdMob App ID: 유지
6. versionName: 1.0.11
7. versionCode: 21
8. R8 / shrinkResources: 유지

v80 점검 중 추가 발견 및 v81 수정
A. 상세 자동반영 ON + 상세정산이 없는 날짜
   - 기존에는 빠른정산 기록이 있어도 입력칸을 0원으로 표시할 수 있었음.
   - v81에서 상세 데이터가 있는 날짜만 상세합계를 사용하고,
     없는 날짜는 기존 빠른정산 기록을 유지하도록 수정.

B. 글자 크기 설정 백업 누락
   - 기존 백업은 테마는 저장하지만 글자 크기는 저장하지 않았음.
   - v81 백업 schemaVersion 6에서 fontSize도 저장/복원.

C. 오래된 직원 백업 호환
   - 직원 id가 없거나 바뀐 구형 백업에서 상세정산 직원 체크가 안 붙을 수 있었음.
   - id 우선, 이름 보조 매칭 추가.
   - 직원 id 누락 시 legacy id 자동 생성.

D. 복원 데이터 방어
   - 잘못된 record 객체/날짜가 섞여도 앱 전체가 깨지지 않도록 record sanitize 강화.

남은 사항
- 정적 코드 점검으로는 실제 WebView/기기 렌더링과 Play 배포 서명까지 100% 보장할 수 없음.
- 내부 테스트 AAB로 실제 기기에서 백업→복원→상세정산→뒤로가기→광고 순서 최종 확인 필요.
