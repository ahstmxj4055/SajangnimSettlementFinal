# v78 Compact header match

사용자 피드백 반영:
- 홈 상단바가 설정 화면보다 너무 높고 빈 공간이 많던 문제 수정
- 설정 버튼과 제목/부제 수직 중심 정렬
- 설정 화면 상단바와 유사한 높이/좌우 여백 사용
- 홈 헤더 아래 요약 카드 시작 간격 축소
- v76/v77의 뒤로가기, AD_ID, R8, AndroidX, 광고/UMP 수정 유지
- versionCode 18
- versionName 1.0.11
