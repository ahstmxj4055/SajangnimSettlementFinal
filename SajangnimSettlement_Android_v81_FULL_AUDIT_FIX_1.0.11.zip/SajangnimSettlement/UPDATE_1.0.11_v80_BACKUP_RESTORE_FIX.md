# v80 Backup / Restore Fix

Fixes the detail-settlement restore bug found during 5-month backup testing.

Problem:
- Current app stores detail data as `sales {...}` and `expense {...}`.
- Restore sanitizer still expected the old flat fields (`cash`, `card`, `material`, ...).
- Monthly totals/records restored, but detail settlement input boxes displayed 0.

v80:
- Preserves current nested detail structure during restore.
- Converts old flat backups to the current nested structure for backward compatibility.
- Preserves custom sales/expense rows, employee checks/pay, daily workers, memo and updatedAt.
- Adds local old-format detail migration.
- Keeps v79 UI/header/back/AD_ID/R8/AndroidX/Ads/UMP changes.
- versionName 1.0.11
- versionCode 20

Important:
If a backup was already imported with the broken v79 restore path, re-import the original JSON backup in v80.
