# v79 FINAL

Final 1.0.11 candidate based on v78.

Changes:
- Visible app version text updated from 1.0.10 to 1.0.11
- versionCode 19
- versionName 1.0.11
- v78 compact home header retained
- Android 13+ back handling retained
- AD_ID / R8 / AndroidX / Ads / UMP retained
- Existing UI/data structure otherwise unchanged

Visible 1.0.10 occurrences replaced: 3
