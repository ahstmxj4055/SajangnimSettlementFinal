# 사장님 정산 Android

현재 웹앱을 Android WebView 앱으로 패키징한 테스트 프로젝트입니다.

## 빌드
GitHub Actions는 JDK 17 + Gradle 8.7 + Android Gradle Plugin 8.5.2 조합으로 빌드합니다.
Gradle Wrapper(gradlew)에 의존하지 않으므로 이전의 `gradlew: No such file or directory` 오류가 발생하지 않습니다.
