# 사장님 정산 Android - API 36 Store Build

- compileSdk 36
- targetSdk 36 (Android 16)
- minSdk 24
- JDK 17
- Android Gradle Plugin 8.10.1
- Gradle 8.11.1
- Release APK + Google Play용 Release AAB 동시 빌드
- 기존 WebView 뒤로가기 동작 보존을 위해 predictive back 콜백은 임시 opt-out 처리
- 기존 상태바/하단바 inset 처리 유지

GitHub Actions에서 서명된 APK와 AAB를 모두 생성합니다.
Google Play에는 AAB(app-release.aab)를 사용하세요.
