#!/usr/bin/env python3
"""Inventory deprecated window-color method references in the built release APK.

Reports dependencies too. Presence is not proof that the method executes on Android
15. Absence does not guarantee Play's complete edge-to-edge recommendation clears.
"""
import json
import struct
import sys
import zipfile

TARGETS = {('Landroid/view/Window;', 'setStatusBarColor'),
           ('Landroid/view/Window;', 'setNavigationBarColor')}


def u32(data, offset):
    return struct.unpack_from('<I', data, offset)[0]


def dex_string(data, offset):
    # Skip UTF-16 length (ULEB128); relevant owner/method names are ASCII.
    while data[offset] & 0x80:
        offset += 1
    offset += 1
    return data[offset:data.index(0, offset)].decode('utf-8', errors='replace')


def inspect(data, name):
    if not data.startswith(b'dex\n'):
        raise ValueError('Unsupported non-DEX entry: ' + name)
    strings_count, strings_offset = u32(data, 56), u32(data, 60)
    strings = [dex_string(data, u32(data, strings_offset + i * 4))
               for i in range(strings_count)]
    types_count, types_offset = u32(data, 64), u32(data, 68)
    types = [strings[u32(data, types_offset + i * 4)] for i in range(types_count)]
    methods_count, methods_offset = u32(data, 88), u32(data, 92)
    found = []
    for i in range(methods_count):
        owner_index, _, name_index = struct.unpack_from('<HHI', data, methods_offset + i * 8)
        owner, method = types[owner_index], strings[name_index]
        if (owner, method) in TARGETS:
            found.append({'dex': name, 'owner': owner, 'method': method})
    return found


def main():
    with zipfile.ZipFile(sys.argv[1]) as apk:
        dexes = [n for n in apk.namelist() if n.startswith('classes') and n.endswith('.dex')]
        if not dexes:
            raise ValueError('No DEX entries found')
        references = [ref for name in dexes for ref in inspect(apk.read(name), name)]
    print(json.dumps({'apk': sys.argv[1], 'dex_files': dexes,
        'deprecated_window_color_references': references,
        'found': bool(references),
        'scope': 'Whole release APK, including third-party SDKs. Inventory only.',
        'cutout_constant_scan': 'Not assessed: inlined integer constants cannot be attributed reliably.'},
        indent=2))


if __name__ == '__main__':
    main()
