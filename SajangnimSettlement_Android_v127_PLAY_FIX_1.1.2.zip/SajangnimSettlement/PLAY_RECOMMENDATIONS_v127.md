# Play Console 권장 조치 대응 · v127

| 표시된 항목 | 변경 | 남은 확인 |
| --- | --- | --- |
| 일부 사용자에게 더 넓은 화면이 표시되지 않을 수 있음 | 네이티브 시스템 바·컷아웃·IME 인셋 처리, CSS 중복 제거 | Android 14/15/16 실기기 화면 검사 |
| 중단된 화면 API/파라미터 | 앱의 enableEdgeToEdge 경로 제거, 투명 바 테마 및 전용 배경 View, ALWAYS 컷아웃 사용 | 새 릴리스 DEX 보고서와 Play 분석. 외부 SDK 사용은 남을 수 있음 |
| R8 메모리/성능 개선 | AGP 9.0.1, Gradle 9.1.0, optimizedResourceShrinking=true | CI release 빌드·런타임·Play 새 버전 분석 |

## 공식 근거
- https://developer.android.com/develop/ui/views/layout/edge-to-edge-manually
- https://developer.android.com/about/versions/15/behavior-changes-15
- https://developer.android.com/build/releases/agp-9-0-0-release-notes
- https://developer.android.com/topic/performance/app-optimization/enable-app-optimization

구글은 일반적으로 enableEdgeToEdge 헬퍼를 권장합니다. 이 프로젝트에서는 해당 호출이 난독화되어 보고된 API 사용 경로의 후보여서, 공식 문서에 제시된 수동 설정 방식으로 옮겼습니다. 실제 원인 확정과 경고 제거 여부는 새 릴리스 분석이 필요합니다.

원본 스크린샷은 버전 56(1.1.0) 기준입니다. 이번 소스는 58(1.1.2)입니다.
Android 빌드는 이 작업 환경에서 실행하지 못했습니다. 기존 16개 DOM 회귀 검사와 Java/JavaScript/XML 문법·설정 검사를 수행했습니다. 빌드 도구 변경이 포함되므로 스토어 제출 전 CI 빌드와 실기기 테스트가 필요합니다.
