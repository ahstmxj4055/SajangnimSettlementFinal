# v127 · 1.1.2 (versionCode 58)

v126 기능 수정 전체를 유지하면서 Play Console 권장 조치 대응을 추가했습니다.
- 상단·좌우·하단 시스템 영역과 디스플레이 컷아웃·키보드 인셋을 네이티브에서 처리.
- 웹 CSS 상단 safe-area 중복 제거, 상태바 보호용 View와 투명 테마 적용.
- 앱의 enableEdgeToEdge 호출 제거, Android 11+ ALWAYS 컷아웃 모드 사용.
- AGP 9.0.1 / Gradle 9.1.0으로 변경, 최적화 리소스 축소 활성화.
- CI Release APK 전체의 중단 Window 색상 API 참조 보고서 추가.
- Java/JS/XML 문법·소스 설정 검사와 DOM 회귀 검사 16개 통과. Android 빌드 및 실기기·Play 재분석은 미실행.

사진에 표시된 56(1.1.0)은 기존 출시 파일입니다. 새 58(1.1.2) AAB를 빌드·검증·업로드한 뒤 해당 버전의 분석으로 확인해야 합니다. 외부 SDK의 참조나 일반 안내는 계속 표시될 수 있습니다.
