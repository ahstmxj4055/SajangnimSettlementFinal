package com.sajangnim.settlement;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.content.Context;
import android.util.Base64;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context newBase) {
        android.content.res.Configuration config =
            new android.content.res.Configuration(newBase.getResources().getConfiguration());
        config.fontScale = 1.0f;
        android.content.Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }


    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final String LIVE_BANNER_AD_UNIT_ID = "ca-app-pub-8303166591303807/4822308146";
    private LinearLayout rootLayout;
    private View statusBarProtection;
    private WebView webView;
    private WebView printWebView;
    private WebView imageWebView;
    private final java.util.concurrent.ExecutorService exportExecutor = java.util.concurrent.Executors.newSingleThreadExecutor();
    private boolean exportBusy = false;
    private String pendingShareMime = null;
    private Uri latestExportUri = null;
    private Uri savedExportUri = null;
    private String savedExportMime = null;

    private void finishExportShare(String mime) {
        savedExportUri = latestExportUri; savedExportMime = mime;
        if (!mime.equals(pendingShareMime)) return;
        pendingShareMime = null;
        Uri uri = latestExportUri;
        latestExportUri = null;
        if (uri == null) {
            webView.evaluateJavascript("if(typeof onNativeShareFailed==='function')onNativeShareFailed();", null);
            return;
        }
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mime);
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "문서 공유하기"));
        } catch (Exception e) {
            webView.evaluateJavascript("if(typeof onNativeShareFailed==='function')onNativeShareFailed();", null);
        }
    }

    private void cleanupExportView(WebView view) {
        if (view == null) return;
        try {
            view.stopLoading();
            if (view.getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup)view.getParent()).removeView(view);
            view.destroy();
        } catch (Exception ignored) {}
        if (imageWebView == view) imageWebView = null;
        exportBusy = false;
    }
    private FrameLayout adContainer;
    private AdView adView;
    private ValueCallback<Uri[]> filePathCallback;
    private ConsentInformation consentInformation;
    private final AtomicBoolean mobileAdsInitialized = new AtomicBoolean(false);
    private volatile boolean mobileAdsReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Draw the window edge-to-edge; our own Views protect interactive content.
        // Avoid the helper that calls deprecated system-bar color/cutout APIs.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        if (Build.VERSION.SDK_INT >= 30) {
            android.view.WindowManager.LayoutParams attributes = getWindow().getAttributes();
            attributes.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            getWindow().setAttributes(attributes);
        }

        // 1.0.10과 동일한 구조: WebView + 하단 광고.
        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(Color.WHITE);

        statusBarProtection = new View(this);
        rootLayout.addView(statusBarProtection, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0));

        WebView.enableSlowWholeDocumentDraw();
        webView = new WebView(this);
        rootLayout.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        adContainer = new FrameLayout(this);
        rootLayout.addView(adContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(rootLayout);

        // Android 13+ predictive-back 환경에서도 기존 앱의 뒤로가기 동작을 그대로 사용합니다.
        // Activity.onBackPressed()만 의존하면 targetSdk 35+ 기기에서 호출되지 않는 경우가 있어
        // 시스템 Back Dispatcher에 동일한 처리기를 등록합니다.
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    new OnBackInvokedCallback() {
                        @Override
                        public void onBackInvoked() {
                            handleAppBack();
                        }
                    }
            );
        }

        // One owner for insets: native layout. HTML safe-top is zero to avoid
        // applying both native padding and WebView CSS safe-area offsets.
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout, (v, insets) -> {
            androidx.core.graphics.Insets safe = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            int keyboardBottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom;
            LinearLayout.LayoutParams protectionParams =
                    (LinearLayout.LayoutParams) statusBarProtection.getLayoutParams();
            if (protectionParams.height != safe.top) {
                protectionParams.height = safe.top;
                statusBarProtection.setLayoutParams(protectionParams);
            }
            v.setPadding(safe.left, 0, safe.right, Math.max(safe.bottom, keyboardBottom));
            return WindowInsetsCompat.CONSUMED;
        });

        ViewCompat.requestApplyInsets(rootLayout);
        applySystemBarsTheme(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setTextZoom(100);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme()) && "/android_asset/index.html".equals(uri.getPath())) return false;
                if ("https".equals(uri.getScheme()) || "mailto".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                updatePrivacyOptionsAvailability();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {

                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }

                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);

                // 일부 Android 파일 앱/제조사 파일 선택기는 .json 파일을
                // application/json이 아니라 text/plain 또는
                // application/octet-stream으로 분류하기도 합니다.
                // 한 MIME 타입으로 제한하면 정상 백업 파일이 목록에서 사라질 수 있어
                // 파일 선택 화면에서는 넓게 허용하고, 실제 JSON 검증은 앱에서 수행합니다.
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                        "application/json",
                        "text/json",
                        "text/plain",
                        "application/octet-stream"
                });

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    // ACTION_OPEN_DOCUMENT를 지원하지 않는 파일 앱 대비
                    try {
                        Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType("*/*");
                        startActivityForResult(fallback, FILE_CHOOSER_REQUEST);
                        return true;
                    } catch (Exception ignored) {
                        MainActivity.this.filePathCallback = null;
                        return false;
                    }
                }
            }
        });

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    2001
            );
        }

        webView.loadUrl("file:///android_asset/index.html");

        // Production ads are requested only after UMP has refreshed the user's consent status.
        requestConsentAndInitializeAds();
    }

    private void applySystemBarsTheme(boolean dark) {
        int statusColor = Color.parseColor(dark ? "#111827" : "#24364B");
        int navigationColor = Color.parseColor((dark || Build.VERSION.SDK_INT < 26) ? "#111827" : "#FFFFFF");

        if (statusBarProtection != null) statusBarProtection.setBackgroundColor(statusColor);
        if (webView != null) webView.setBackgroundColor(statusColor);
        if (rootLayout != null) {
            rootLayout.setBackgroundColor(navigationColor);
        }

        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        // Status bar is navy/dark in both themes, so keep icons light.
        controller.setAppearanceLightStatusBars(false);
        // Light theme uses a white navigation area with dark icons.
        controller.setAppearanceLightNavigationBars(!dark);
    }

    public class AndroidBridge {
    @JavascriptInterface
    public void shareHtmlDocument(String html, String fileName, String format) {
        runOnUiThread(() -> {
            if (exportBusy) {
                webView.evaluateJavascript("if(typeof onNativeShareFailed==='function')onNativeShareFailed();", null);
                return;
            }
            pendingShareMime = "png".equals(format) ? "image/png" : "application/pdf";
            latestExportUri = null;
            if ("png".equals(format)) saveHtmlAsImage(html, fileName);
            else saveHtmlAsPdf(html, fileName);
        });
    }



        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> finish());
        }

        @JavascriptInterface
        public void setAppFontScale(int percent) {
            final int safePercent = Math.max(80, Math.min(130, percent));
            runOnUiThread(() -> {
                if (webView != null) {
                    webView.getSettings().setTextZoom(safePercent);
                }
            });
        }

        @JavascriptInterface
        public void setSystemBarsTheme(boolean dark) {
            runOnUiThread(() -> applySystemBarsTheme(dark));
        }
        @JavascriptInterface
        public void openAdPrivacyOptions() {
            runOnUiThread(() -> {
                if (consentInformation == null ||
                        consentInformation.getPrivacyOptionsRequirementStatus() !=
                                ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED) {
                    showWebToast("현재 변경할 광고 개인정보 설정이 없습니다.");
                    return;
                }

                UserMessagingPlatform.showPrivacyOptionsForm(
                        MainActivity.this,
                        formError -> {
                            updatePrivacyOptionsAvailability();
                            if (formError != null) {
                                showWebToast("광고 개인정보 설정을 열 수 없습니다.");
                                return;
                            }
                            if (consentInformation.canRequestAds()) {
                                if (mobileAdsReady) {
                                    reloadLiveBanner();
                                } else {
                                    initializeMobileAdsOnce();
                                }
                            } else {
                                clearBanner();
                            }
                        }
                );
            });
        }

        @JavascriptInterface
        public void saveBackup(String json, String fileName) {
            runOnUiThread(() -> {
                try {
                    String safeName = (fileName == null || fileName.trim().isEmpty())
                            ? "사장님정산_백업.json"
                            : fileName;

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentResolver resolver = getContentResolver();
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                        values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (uri == null) throw new Exception("다운로드 파일을 만들 수 없습니다.");

                        try (OutputStream out = resolver.openOutputStream(uri)) {
                            if (out == null) throw new Exception("파일을 열 수 없습니다.");
                            out.write(json.getBytes(StandardCharsets.UTF_8));
                            out.flush();
                        }
                    } else {
                        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                        if (!downloads.exists() && !downloads.mkdirs()) {
                            throw new Exception("다운로드 폴더를 만들 수 없습니다.");
                        }

                        File target = new File(downloads, safeName);
                        try (FileOutputStream out = new FileOutputStream(target)) {
                            out.write(json.getBytes(StandardCharsets.UTF_8));
                            out.flush();
                        }
                    }

                    webView.evaluateJavascript(
                            "if(typeof onNativeBackupSaved==='function'){onNativeBackupSaved();}",
                            null
                    );
                } catch (Exception e) {
                    webView.evaluateJavascript(
                            "if(typeof onNativeBackupFailed==='function'){onNativeBackupFailed();}",
                            null
                    );
                }
            });
        }

        @JavascriptInterface
        public void openLatestExport() {
            runOnUiThread(() -> {
                if (savedExportUri == null) return;
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(savedExportUri, savedExportMime);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(intent, "저장 파일 열기"));
                } catch (Exception e) {
                    webView.evaluateJavascript("showAppMessage('파일을 열 수 있는 앱이 없어요. 다운로드 폴더에서 확인해주세요.')", null);
                }
            });
        }

        @JavascriptInterface
        public void shareLatestExport() {
            runOnUiThread(() -> {
                if (savedExportUri == null) return;
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(savedExportMime);
                    send.putExtra(Intent.EXTRA_STREAM, savedExportUri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "저장 파일 공유"));
                } catch (Exception e) {
                    webView.evaluateJavascript("onNativeShareFailed()", null);
                }
            });
        }

        @JavascriptInterface
        public void saveBase64File(String base64Data, String fileName, String mimeType) {
            runOnUiThread(() -> {
                try {
                    String safeName = (fileName == null || fileName.trim().isEmpty()) ? "사장님정산_파일.bin" : fileName;
                    String safeMime = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType;
                    byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentResolver resolver = getContentResolver();
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                        values.put(MediaStore.Downloads.MIME_TYPE, safeMime);
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (uri == null) throw new Exception("다운로드 파일을 만들 수 없습니다.");
                        try (OutputStream out = resolver.openOutputStream(uri)) {
                            if (out == null) throw new Exception("파일을 열 수 없습니다.");
                            out.write(bytes); out.flush();
                        }
                        savedExportUri = uri; savedExportMime = safeMime;
                    } else {
                        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                        if (!downloads.exists() && !downloads.mkdirs()) throw new Exception("다운로드 폴더를 만들 수 없습니다.");
                        File target = new File(downloads, safeName);
                        try (FileOutputStream out = new FileOutputStream(target)) { out.write(bytes); out.flush(); }
                        savedExportUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", target);
                        savedExportMime = safeMime;
                    }
                    String escaped = safeName.replace("\\", "\\\\").replace("'", "\\'");
                    webView.evaluateJavascript("if(typeof onNativeFileSaved==='function'){onNativeFileSaved('" + escaped + "');}", null);
                } catch (Exception e) {
                    webView.evaluateJavascript("if(typeof onNativeFileFailed==='function'){onNativeFileFailed();}", null);
                }
            });
        }

        @JavascriptInterface
        public void saveHtmlAsImage(String html, String fileName) {
            runOnUiThread(() -> {
                if (exportBusy) {
                    webView.evaluateJavascript("if(typeof onNativeImageFailed==='function'){onNativeImageFailed();}", null);
                    return;
                }
                exportBusy = true;
                try {
                    final String safeName;
                    if (fileName == null || fileName.trim().isEmpty()) {
                        safeName = "사장님정산_문서.png";
                    } else if (fileName.toLowerCase().endsWith(".png")) {
                        safeName = fileName;
                    } else {
                        safeName = fileName + ".png";
                    }

                    final String safeHtml =
                            (html == null || html.trim().isEmpty())
                                    ? "<html><body>문서 내용이 없습니다.</body></html>"
                                    : html;

                    if (imageWebView != null) {
                        try { if (imageWebView.getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup)imageWebView.getParent()).removeView(imageWebView); imageWebView.destroy(); } catch (Exception ignored) {}
                        imageWebView = null;
                    }

                    imageWebView = new WebView(MainActivity.this);
                    imageWebView.setBackgroundColor(Color.WHITE);
                    imageWebView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                    // Attach export WebView to window so page load/draw can complete.
                    FrameLayout decor = (FrameLayout) getWindow().getDecorView().findViewById(android.R.id.content);
                    FrameLayout.LayoutParams exportParams = new FrameLayout.LayoutParams(1240, 1754);
                    exportParams.gravity = android.view.Gravity.TOP | android.view.Gravity.LEFT;
                    decor.addView(imageWebView, exportParams);
                    imageWebView.setAlpha(0.02f);
                    imageWebView.setClickable(false);
                    imageWebView.setFocusable(false);
                    imageWebView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);

                    WebSettings settings = imageWebView.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDefaultTextEncodingName("UTF-8");
                    settings.setLoadWithOverviewMode(false);
                    settings.setUseWideViewPort(false);

                    imageWebView.setWebViewClient(new WebViewClient() {
                        private boolean started = false;

                        @Override
                        public void onPageFinished(WebView view, String url) {
                            super.onPageFinished(view, url);
                            if (started) return;
                            started = true;

                            view.postDelayed(() -> view.postVisualStateCallback(System.nanoTime(), new WebView.VisualStateCallback() {
                                @Override public void onComplete(long requestId) {
                                    view.postDelayed(() -> view.evaluateJavascript(
                                    "(function(){return Math.max(document.body.scrollHeight||0,document.documentElement.scrollHeight||0,1200);})()",
                                    value -> {
                                        try {
                                            double cssHeight = 1600;
                                            if (value != null && !"null".equals(value)) {
                                                cssHeight = Double.parseDouble(value.replace("\"", ""));
                                            }

                                            final int widthPx = 1240;
                                            int heightPx = Math.max(1400, (int)Math.ceil(cssHeight * view.getScale()));
                                            if (heightPx > 175400) throw new Exception("Document exceeds 100 pages");

                                            view.measure(
                                                    View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
                                                    View.MeasureSpec.makeMeasureSpec(heightPx, View.MeasureSpec.EXACTLY)
                                            );
                                            view.layout(0, 0, widthPx, heightPx);

                                            double scale = Math.min(1.0, Math.min(16000.0 / heightPx,
                                                    Math.sqrt(10000000.0 / ((double)widthPx * heightPx))));
                                            Bitmap bitmap = Bitmap.createBitmap(Math.max(1, (int)Math.ceil(widthPx * scale)),
                                                    Math.max(1, (int)Math.ceil(heightPx * scale)), Bitmap.Config.ARGB_8888);
                                            Canvas canvas = new Canvas(bitmap);
                                            canvas.drawColor(Color.WHITE);
                                            canvas.scale((float)scale, (float)scale);
                                            view.draw(canvas);

                                            if (isExportBitmapBlank(bitmap)) throw new Exception("Blank image render");
                                            final Bitmap readyBitmap = bitmap;
                                            final WebView exportView = view;
                                            exportExecutor.execute(() -> {
                                                boolean ok = false;
                                                try {
                                                    latestExportUri = saveBitmapToDownloads(readyBitmap, safeName);
                                                    ok = true;
                                                } catch (Exception ignored) {
                                                } finally {
                                                    readyBitmap.recycle();
                                                }
                                                final boolean saved = ok;
                                                runOnUiThread(() -> {
                                                    cleanupExportView(exportView);
                                                    if (saved) {
                                                        finishExportShare("image/png");
                                                        String escapedName = safeName.replace("\\", "\\\\").replace("'", "\\'");
                                                        webView.evaluateJavascript("if(typeof onNativeImageSaved==='function'){onNativeImageSaved('" + escapedName + "');}", null);
                                                    } else {
                                                        webView.evaluateJavascript("if(typeof onNativeImageFailed==='function'){onNativeImageFailed();}", null);
                                                    }
                                                });
                                            });
                                            return;
                                        } catch (Exception e) {
                                            cleanupExportView(view);
                                            webView.evaluateJavascript(
                                                    "if(typeof onNativeImageFailed==='function'){onNativeImageFailed();}",
                                                    null
                                            );
                                        }
                                    }
                            ), 250);
                                }
                            }), 650);
                        }
                    });

                    imageWebView.loadDataWithBaseURL(
                            "https://local.sajangnim/",
                            safeHtml,
                            "text/html",
                            "UTF-8",
                            null
                    );
                } catch (Exception e) {
                    cleanupExportView(imageWebView);
                    webView.evaluateJavascript(
                            "if(typeof onNativeImageFailed==='function'){onNativeImageFailed();}",
                            null
                    );
                }
            });
        }

        @JavascriptInterface
        public void saveHtmlAsPdf(String html, String fileName) {
            runOnUiThread(() -> {
                if (exportBusy) {
                    webView.evaluateJavascript("if(typeof onNativePdfFailed==='function'){onNativePdfFailed();}", null);
                    return;
                }
                exportBusy = true;
                try {
                    final String safeName;
                    if (fileName == null || fileName.trim().isEmpty()) {
                        safeName = "사장님정산_문서.pdf";
                    } else if (fileName.toLowerCase().endsWith(".pdf")) {
                        safeName = fileName;
                    } else {
                        safeName = fileName + ".pdf";
                    }

                    final String safeHtml =
                            (html == null || html.trim().isEmpty())
                                    ? "<html><body>문서 내용이 없습니다.</body></html>"
                                    : html;

                    if (imageWebView != null) {
                        try { if (imageWebView.getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup)imageWebView.getParent()).removeView(imageWebView); imageWebView.destroy(); } catch (Exception ignored) {}
                        imageWebView = null;
                    }

                    imageWebView = new WebView(MainActivity.this);
                    imageWebView.setBackgroundColor(Color.WHITE);
                    imageWebView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                    // Attach export WebView to window so page load/draw can complete.
                    FrameLayout decor = (FrameLayout) getWindow().getDecorView().findViewById(android.R.id.content);
                    FrameLayout.LayoutParams exportParams = new FrameLayout.LayoutParams(1240, 1754);
                    exportParams.gravity = android.view.Gravity.TOP | android.view.Gravity.LEFT;
                    decor.addView(imageWebView, exportParams);
                    imageWebView.setAlpha(0.02f);
                    imageWebView.setClickable(false);
                    imageWebView.setFocusable(false);
                    imageWebView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);

                    WebSettings settings = imageWebView.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDefaultTextEncodingName("UTF-8");
                    settings.setLoadWithOverviewMode(false);
                    settings.setUseWideViewPort(false);

                    imageWebView.setWebViewClient(new WebViewClient() {
                        private boolean started = false;

                        @Override
                        public void onPageFinished(WebView view, String url) {
                            super.onPageFinished(view, url);
                            if (started) return;
                            started = true;

                            view.postDelayed(() -> view.postVisualStateCallback(System.nanoTime(), new WebView.VisualStateCallback() {
                                @Override public void onComplete(long requestId) {
                                    view.postDelayed(() -> view.evaluateJavascript(
                                    "(function(){return Math.max(document.body.scrollHeight||0,document.documentElement.scrollHeight||0,1200);})()",
                                    value -> {
                                        try {
                                            double cssHeight = 1600;
                                            if (value != null && !"null".equals(value)) {
                                                cssHeight = Double.parseDouble(value.replace("\"", ""));
                                            }

                                            final int widthPx = 1240;
                                            final int heightPx = Math.max(1400, (int)Math.ceil(cssHeight * view.getScale()));
                                            if (heightPx > 175400) throw new Exception("Document exceeds 100 pages");
                                            view.measure(View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
                                                    View.MeasureSpec.makeMeasureSpec(heightPx, View.MeasureSpec.EXACTLY));
                                            view.layout(0, 0, widthPx, heightPx);
                                            final android.graphics.pdf.PdfDocument pdf = new android.graphics.pdf.PdfDocument();
                                            try {
                                                for (int offset = 0, n = 1; offset < heightPx; offset += 1754, n++) {
                                                    android.graphics.pdf.PdfDocument.Page page = pdf.startPage(
                                                        new android.graphics.pdf.PdfDocument.PageInfo.Builder(1240, 1754, n).create());
                                                    Canvas canvas = page.getCanvas();
                                                    canvas.drawColor(Color.WHITE);
                                                    canvas.save(); canvas.translate(0, -offset); view.draw(canvas); canvas.restore();
                                                    pdf.finishPage(page);
                                                }
                                            } catch (Exception e) { pdf.close(); throw e; }
                                            final WebView exportView = view;
                                            exportExecutor.execute(() -> {
                                                boolean ok = false;
                                                try { latestExportUri = writePdfToDownloads(pdf, safeName); ok = true; }
                                                catch (Exception ignored) {} finally { pdf.close(); }
                                                final boolean saved = ok;
                                                runOnUiThread(() -> {
                                                    cleanupExportView(exportView);
                                                    if (saved) { finishExportShare("application/pdf"); webView.evaluateJavascript("onNativePdfSaved()", null); }
                                                    else webView.evaluateJavascript("onNativePdfFailed()", null);
                                                });
                                            });
                                            return;
                                        } catch (Exception e) {
                                            cleanupExportView(view);
                                            webView.evaluateJavascript(
                                                    "if(typeof onNativePdfFailed==='function'){onNativePdfFailed();}",
                                                    null
                                            );
                                        }
                                    }
                            ), 250);
                                }
                            }), 650);
                        }
                    });

                    imageWebView.loadDataWithBaseURL(
                            "https://local.sajangnim/",
                            safeHtml,
                            "text/html",
                            "UTF-8",
                            null
                    );
                } catch (Exception e) {
                    cleanupExportView(imageWebView);
                    webView.evaluateJavascript(
                            "if(typeof onNativePdfFailed==='function'){onNativePdfFailed();}",
                            null
                    );
                }
            });
        }

        private boolean isExportBitmapBlank(Bitmap bmp) {
            int width=bmp.getWidth(),height=bmp.getHeight();
            int colored=0;
            for (int y=0;y<height;y+=Math.max(1,height/65)) {
                for (int x=0;x<width;x+=Math.max(1,width/45)) {
                    int pixel=bmp.getPixel(x,y);
                    if (Color.red(pixel)<235 || Color.green(pixel)<235 || Color.blue(pixel)<235) {
                        if (++colored>=4) return false;
                    }
                }
            }
            return true;
        }

        private Uri writePdfToDownloads(android.graphics.pdf.PdfDocument document, String safeName) throws Exception {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentResolver resolver = getContentResolver();
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("PDF 파일을 만들 수 없습니다.");
                    try (OutputStream out = resolver.openOutputStream(uri)) {
                        if (out == null) throw new Exception("PDF 파일을 열 수 없습니다.");
                        document.writeTo(out);
                    } catch (Exception e) { resolver.delete(uri, null, null); throw e; }
                    return uri;
                } else {
                    File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!downloads.exists() && !downloads.mkdirs()) throw new Exception("다운로드 폴더를 만들 수 없습니다.");
                    File file = new File(downloads, safeName);
                    try (FileOutputStream out = new FileOutputStream(file)) { document.writeTo(out); }
                    return FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                }
        }

        private Uri saveBitmapToDownloads(Bitmap bitmap, String safeName) throws Exception {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                values.put(MediaStore.Downloads.MIME_TYPE, "image/png");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("이미지 파일을 만들 수 없습니다.");

                try (OutputStream out = resolver.openOutputStream(uri)) {
                    if (out == null) throw new Exception("이미지 파일을 열 수 없습니다.");
                    if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                        throw new Exception("이미지 저장에 실패했습니다.");
                    }
                    out.flush();
                }
                return uri;
            } else {
                File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloads.exists() && !downloads.mkdirs()) {
                    throw new Exception("다운로드 폴더를 만들 수 없습니다.");
                }
                File file = new File(downloads, safeName);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                        throw new Exception("이미지 저장에 실패했습니다.");
                    }
                    out.flush();
                }
                return FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
            }
        }

        @JavascriptInterface
        public void printCurrentPage(String title) {
            runOnUiThread(() -> {
                if (webView == null) return;
                try {
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    String jobName = (title == null || title.trim().isEmpty()) ? "사장님 정산 문서" : title;
                    PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(jobName);
                    printManager.print(jobName, adapter, new PrintAttributes.Builder().build());
                } catch (Exception e) {
                    showWebToast("PDF/인쇄 화면을 열 수 없습니다.");
                }
            });
        }

        @JavascriptInterface
        public void printHtml(String html, String title) {
            runOnUiThread(() -> {
                try {
                    final String jobName =
                            (title == null || title.trim().isEmpty()) ? "사장님 정산 문서" : title;
                    final String safeHtml =
                            (html == null || html.trim().isEmpty())
                                    ? "<html><body>문서 내용이 없습니다.</body></html>"
                                    : html;

                    if (printWebView != null) {
                        try { printWebView.destroy(); } catch (Exception ignored) {}
                        printWebView = null;
                    }

                    printWebView = new WebView(MainActivity.this);
                    WebSettings printSettings = printWebView.getSettings();
                    printSettings.setJavaScriptEnabled(false);
                    printSettings.setDefaultTextEncodingName("UTF-8");

                    printWebView.setWebViewClient(new WebViewClient() {
                        private boolean started = false;

                        @Override
                        public void onPageFinished(WebView view, String url) {
                            super.onPageFinished(view, url);
                            if (started) return;
                            started = true;

                            view.postDelayed(() -> {
                                try {
                                    PrintManager printManager =
                                            (PrintManager) getSystemService(Context.PRINT_SERVICE);
                                    PrintDocumentAdapter adapter =
                                            view.createPrintDocumentAdapter(jobName);
                                    printManager.print(
                                            jobName,
                                            adapter,
                                            new PrintAttributes.Builder()
                                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                                                .build()
                                    );
                                } catch (Exception e) {
                                    showWebToast("PDF/인쇄 화면을 열 수 없습니다.");
                                }
                            }, 250);
                        }
                    });

                    printWebView.loadDataWithBaseURL(
                            "https://local.sajangnim/",
                            safeHtml,
                            "text/html",
                            "UTF-8",
                            null
                    );
                } catch (Exception e) {
                    showWebToast("PDF/인쇄 화면을 열 수 없습니다.");
                }
            });
        }

    }

    private void requestConsentAndInitializeAds() {
        consentInformation = UserMessagingPlatform.getConsentInformation(this);

        ConsentRequestParameters params = new ConsentRequestParameters.Builder().build();
        consentInformation.requestConsentInfoUpdate(
                this,
                params,
                () -> {
                    updatePrivacyOptionsAvailability();

                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                            MainActivity.this,
                            formError -> {
                                updatePrivacyOptionsAvailability();
                                if (consentInformation.canRequestAds()) {
                                    initializeMobileAdsOnce();
                                }
                            }
                    );

                    // A previous valid consent decision may already allow ads before a form is needed.
                    if (consentInformation.canRequestAds()) {
                        initializeMobileAdsOnce();
                    }
                },
                requestConsentError -> {
                    updatePrivacyOptionsAvailability();
                    // If a previous valid consent decision exists, ads may still be requested.
                    if (consentInformation.canRequestAds()) {
                        initializeMobileAdsOnce();
                    }
                }
        );

        if (consentInformation.canRequestAds()) {
            initializeMobileAdsOnce();
        }
    }

    private void initializeMobileAdsOnce() {
        if (mobileAdsInitialized.getAndSet(true)) return;

        MobileAds.initialize(this, initializationStatus -> {
            mobileAdsReady = true;
            if (adContainer != null) {
                adContainer.post(this::loadLiveBanner);
            }
        });
    }

    private void loadLiveBanner() {
        if (consentInformation == null || !consentInformation.canRequestAds()) return;

        if (adContainer == null || adContainer.getWidth() <= 0) {
            if (adContainer != null) adContainer.post(this::loadLiveBanner);
            return;
        }

        if (adView != null) {
            adView.destroy();
            adView = null;
        }

        float density = getResources().getDisplayMetrics().density;
        int adWidthDp = Math.max(1, (int) (adContainer.getWidth() / density));
        AdSize adSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidthDp);

        adView = new AdView(this);
        adView.setAdUnitId(LIVE_BANNER_AD_UNIT_ID);
        adView.setAdSize(adSize);
        adContainer.removeAllViews();
        adContainer.addView(adView);
        adView.loadAd(new AdRequest.Builder().build());
    }

    private void clearBanner() {
        if (adView != null) {
            adView.destroy();
            adView = null;
        }
        if (adContainer != null) {
            adContainer.removeAllViews();
        }
    }

    private void reloadLiveBanner() {
        if (adView != null) {
            adView.destroy();
            adView = null;
        }
        if (adContainer != null) {
            adContainer.removeAllViews();
            adContainer.post(this::loadLiveBanner);
        }
    }

    private void updatePrivacyOptionsAvailability() {
        if (webView == null) return;

        boolean required = consentInformation != null &&
                consentInformation.getPrivacyOptionsRequirementStatus() ==
                        ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;

        String script = "if(typeof setAdPrivacyOptionsVisible==='function'){" +
                "setAdPrivacyOptionsVisible(" + required + ");}";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private void showWebToast(String message) {
        if (webView == null) return;
        String safe = message.replace("\\", "\\\\").replace("'", "\\'");
        String script = "if(typeof showBackupToast==='function'){showBackupToast('" + safe + "');}";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    @Override
    protected void onPause() {
        if (adView != null) adView.pause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adView != null) adView.resume();
    }

    @Override
    protected void onDestroy() {
        if (printWebView != null) {
            try { printWebView.destroy(); } catch (Exception ignored) {}
            printWebView = null;
        }
        if (imageWebView != null) {
            try { if (imageWebView.getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup)imageWebView.getParent()).removeView(imageWebView); imageWebView.destroy(); } catch (Exception ignored) {}
            imageWebView = null;
        }
        if (adView != null) adView.destroy();
        exportExecutor.shutdown();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;

            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }

            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    private void handleAppBack() {
        if (webView == null) {
            finish();
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return (typeof handleNativeBackInPage==='function' && handleNativeBackInPage()) ? '1' : '0';}catch(e){return '0';}})()",
                value -> {
                    if ("\"1\"".equals(value)) {
                        return;
                    }

                    // 앱의 화면 전환은 History API(pushState)를 사용하므로
                    // WebView 히스토리가 있으면 이전 화면으로 복귀합니다.
                    if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        webView.evaluateJavascript("showExitConfirm()", null);
                    }
                }
        );
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Android 12 이하용. Android 13+는 OnBackInvokedDispatcher가 호출합니다.
        if (Build.VERSION.SDK_INT < 33) {
            handleAppBack();
        } else {
            handleAppBack();
        }
    }
}
