/* Storage admission and rollback. Loaded before app data. */
const storageRecoveryWarnings=[];
function readStoredJson(key,fallback){
 const raw=localStorage.getItem(key);if(raw===null)return fallback;
 try{const value=JSON.parse(raw);if(!value||typeof value!=='object'||Array.isArray(value)!==Array.isArray(fallback))throw Error('shape');
 if(key==='sajangnim_records'&&value.some(r=>!r||!validCalendarDate(r.date)||['sales','expense','pay'].some(k=>!Number.isFinite(r[k])||r[k]<0)))throw Error('record');
 if(key==='sajangnim_employees'&&value.some(x=>!x||typeof x.name!=='string'||!validDocumentId(x.id)))throw Error('employees');
 if(key==='sajangnim_detail_records'&&Object.entries(value).some(([date,d])=>!validCalendarDate(date)||!d||typeof d!=='object'||['employees','dailyWorkers'].some(k=>d[k]!==undefined&&!Array.isArray(d[k]))||['sales','expense'].some(k=>d[k]&&typeof d[k]==='object'&&d[k].custom!==undefined&&!Array.isArray(d[k].custom))))throw Error('details');
 if(key==='sajangnim_business_docs'&&value.some(d=>!d||!Array.isArray(d.items)||!d.client))throw Error('documents');
 if(key==='sajangnim_records')value.forEach(r=>r.profit=r.sales-r.expense-r.pay);
 return value;
 }catch(e){
 // Keep exact original bytes; never silently delete an unreadable record.
 try{localStorage.setItem('recovery_raw_'+key,raw);localStorage.setItem('recovery_warning_'+key,'1');}catch(ignore){}
 storageRecoveryWarnings.push(key);return fallback;
 }
}
function validCalendarDate(value){if(!/^\d{4}-\d{2}-\d{2}$/.test(String(value)))return false;const [y,m,d]=value.split('-').map(Number);const date=new Date(value+'T12:00:00');return Number.isFinite(date.getTime())&&date.getFullYear()===y&&date.getMonth()+1===m&&date.getDate()===d;}
function finiteMoney(value){const n=Number(value);if(!Number.isFinite(n)||n<0||n>1e14)throw Error('invalid money');return n;}
function validDocumentId(id){return typeof id==='string'&&/^[a-zA-Z0-9_-]{1,100}$/.test(id);}
function newDocumentId(){return 'doc_'+(globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+'_'+Math.random().toString(36).slice(2));}
function validateBackupEnvelope(raw){
 if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('invalid backup');
 if(raw.app!==undefined&&raw.app!=='사장님 정산')throw Error('different app');
 if(raw.schemaVersion!==undefined&&(!Number.isInteger(raw.schemaVersion)||raw.schemaVersion<1||raw.schemaVersion>7))throw Error('unsupported version');
 const data=raw.data===undefined?raw:raw.data;
 if(!data||typeof data!=='object'||Array.isArray(data)||!Array.isArray(data.records))throw Error('missing records');
 for(const k of ['employees','businessDocs'])if(data[k]!==undefined&&!Array.isArray(data[k]))throw Error('invalid '+k);
 for(const k of ['targets','detailRecords','businessProfile'])if(data[k]!==undefined&&(!data[k]||typeof data[k]!=='object'||Array.isArray(data[k])))throw Error('invalid '+k);
 for(const r of data.records){if(!r||!validCalendarDate(r.date))throw Error('invalid date');for(const k of ['sales','expense','pay'])finiteMoney(r[k]??0);}
 for(const d of Object.values(data.detailRecords||{})){
  if(!d||typeof d!=='object'||Array.isArray(d))throw Error('invalid detail');
  for(const group of ['sales','expense'])if(d[group]&&typeof d[group]==='object')for(const [key,value]of Object.entries(d[group])){
   if(key==='custom'){if(!Array.isArray(value))throw Error('invalid custom');for(const row of value)finiteMoney(row?.amount??0);}else finiteMoney(value);
  }
  for(const group of ['employees','dailyWorkers'])if(d[group]!==undefined){if(!Array.isArray(d[group]))throw Error('invalid employee');for(const row of d[group])finiteMoney(row?.pay??0);}
 }
 const ids=new Set();for(const d of data.businessDocs||[]){if(!d||!validCalendarDate(d.date)||!Array.isArray(d.items))throw Error('invalid document');if(d.id&&ids.has(d.id))throw Error('duplicate id');ids.add(d.id);for(const i of d.items){finiteMoney(i?.qty??0);finiteMoney(i?.unitPrice??0);}}
}
function recordPeriod(rows){const dates=rows.map(r=>r.date).sort();return dates.length?dates[0]+' ~ '+dates[dates.length-1]:'기록 없음';}
function storageSnapshot(){const result={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k.startsWith('sajangnim_'))result[k]=localStorage.getItem(k);}return result;}
function writeSnapshot(snapshot){for(let i=localStorage.length-1;i>=0;i--){const k=localStorage.key(i);if(k.startsWith('sajangnim_'))localStorage.removeItem(k);}for(const[k,v]of Object.entries(snapshot))localStorage.setItem(k,v);}
function restoreStateSafely(state){
 const memory=JSON.parse(JSON.stringify({records,targets,detailRecords,employees,detailAutoCalc}));
 const before=storageSnapshot();const checkpoint=JSON.stringify({at:new Date().toISOString(),values:before});
 localStorage.setItem('recovery_before_restore',checkpoint); // Must succeed before first data mutation.
 try{applyRestoredState(state);localStorage.removeItem('sajangnim_form_drafts');for(let i=localStorage.length-1;i>=0;i--){const k=localStorage.key(i);if(k.startsWith('recovery_warning_'))localStorage.removeItem(k);}storageRecoveryWarnings.length=0;}
 catch(e){records=memory.records;targets=memory.targets;detailRecords=memory.detailRecords;employees=memory.employees;detailAutoCalc=memory.detailAutoCalc;try{writeSnapshot(before);applyDetailAutoUI();render();loadDate(selected);}catch(rollbackError){console.error(rollbackError);}throw e;}
}
function undoLastRestore(){
 const raw=localStorage.getItem('recovery_before_restore');if(!raw){showAppMessage('되돌릴 복원 사본이 없어요.');return;}
 openAppModal('직전 복원 이전 상태로 되돌릴까요? 복원 후 작성한 내용은 사라집니다.',{showCancel:true,confirmText:'되돌리기',onConfirm:()=>{try{const saved=JSON.parse(raw);const current=storageSnapshot();try{writeSnapshot(saved.values);}catch(e){writeSnapshot(current);throw e;}location.reload();}catch(e){showAppMessage('되돌리기에 실패했어요. 복구용 원본을 저장해주세요.');}}});
}
function exportRecoveryData(){
 const recovery={exportedAt:new Date().toISOString(),current:storageSnapshot(),damaged:{},beforeRestore:localStorage.getItem('recovery_before_restore')};
 for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(key.startsWith('recovery_raw_'))recovery.damaged[key]=localStorage.getItem(key);}
 const data=JSON.stringify(recovery,null,2),name='사장님정산_복구원본_'+localToday()+'.json';
 if(window.Android?.saveBackup)Android.saveBackup(data,name);else{const url=URL.createObjectURL(new Blob([data],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
}
