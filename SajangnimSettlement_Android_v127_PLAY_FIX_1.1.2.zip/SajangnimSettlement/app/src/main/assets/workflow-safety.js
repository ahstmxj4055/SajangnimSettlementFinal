/* Draft recovery, navigation protection and export actions. */
const draftPages={main:['date','sales','expense','pay','memo'],detailsettlement:[],documenteditor:[],documenthub:['bizName','bizOwner','bizNumber','bizPhone','bizAddress','bizEmail']};
const pageBaselines={};let activeDraftPage='main',draftTimer=null;
function formState(page){
 if(page==='documenteditor'){const d=currentDocumentDraft();delete d.updatedAt;delete d.id;return {document:d,id:docEditorId,type:docEditorType};}
 if(page==='detailsettlement')return {date:$('detailDate').value,data:collectDetailDraft()};
 const result={};for(const id of draftPages[page]||[])result[id]=$(id)?.value||'';return result;
}
function draftEqual(a,b){return JSON.stringify(a)===JSON.stringify(b);}
function draftStore(){try{return readStoredJson('sajangnim_form_drafts',{});}catch(e){return {};}}
function persistPageDraft(page=activeDraftPage){
 if(!(page in draftPages))return;
 try{const state=formState(page),baseline=pageBaselines[page];const drafts=draftStore();if(baseline&&draftEqual(state,baseline))delete drafts[page];else drafts[page]={at:new Date().toISOString(),state};localStorage.setItem('sajangnim_form_drafts',JSON.stringify(drafts));}
 catch(e){console.error('draft save',e);if(!window.draftSaveWarning){window.draftSaveWarning=true;showBackupToast('임시저장 공간이 부족해요. 백업 후 공간을 확인해주세요.');}}
}
function markPageSaved(page){try{pageBaselines[page]=formState(page);const drafts=draftStore();delete drafts[page];localStorage.setItem('sajangnim_form_drafts',JSON.stringify(drafts));}catch(e){console.error(e);}}
function applyFormState(page,state){
 if(page==='documenteditor'){docEditorType=state.type;docEditorId=state.id||null;setupDocumentEditor(state.document);}
 else if(page==='detailsettlement'){
  const date=state.date,old=detailRecords[date];detailRecords[date]=state.data;try{loadDetailSettlement(date);}finally{if(old===undefined)delete detailRecords[date];else detailRecords[date]=old;}
 }else{for(const[id,value]of Object.entries(state))if($(id))$(id).value=value;if(page==='main'){if(validCalendarDate(state.date)){selected=state.date;const[y,m]=state.date.split('-').map(Number);view=new Date(y,m-1,1);render();}updateDayPreview();}}
}
function offerDraft(page){
 const saved=draftStore()[page];if(!saved)return;
 openAppModal('저장하지 않은 작성 내용이 있어요. 이어서 작성할까요?',{showCancel:true,confirmText:'이어서 작성',onConfirm:()=>{const baseline=pageBaselines[page];applyFormState(page,saved.state);pageBaselines[page]=baseline;showBackupToast('임시저장 내용을 불러왔어요.');}});
}
function guardUnsavedBack(action){
 const page=history.state?.appPage||'main';if(!(page in draftPages)||!pageBaselines[page])return false;
 if(draftEqual(formState(page),pageBaselines[page]))return false;
 persistPageDraft(page);
 openAppModal('저장하지 않은 내용이 있어요. 임시저장한 뒤 나갈까요?',{showCancel:true,confirmText:'임시저장 후 나가기',onConfirm:action});return true;
}
function validateDocumentDraft(d){
 if(!validCalendarDate(d.date)){showAppMessage('올바른 작성일을 선택해주세요.');return false;}
 if(!d.client.name){showAppMessage('거래처명을 입력해주세요.');return false;}
 if(!d.items.length){showAppMessage('품목을 1개 이상 입력해주세요.');return false;}
 if(d.items.some(i=>!i.name.trim()||!Number.isFinite(i.qty)||i.qty<=0||!Number.isFinite(i.unitPrice)||i.unitPrice<0)){showAppMessage('품목명과 0보다 큰 수량을 입력해주세요. 단가는 0원 이상이어야 해요.');return false;}
 if(!Number.isSafeInteger(Math.round(calcBusinessDocTotals(d).total))){showAppMessage('입력 금액이 너무 커요. 금액과 수량을 확인해주세요.');return false;}return true;
}
// Capture before route functions replace forms. Native back uses the same guard.
document.addEventListener('click',e=>{const back=e.target.closest('.back-btn');if(!back)return;const inline=back.getAttribute('onclick');if(!inline)return;if(guardUnsavedBack(()=>{const fn=inline.match(/^([\w]+)\(\)/)?.[1];if(fn&&typeof window[fn]==='function')window[fn]();})){e.preventDefault();e.stopImmediatePropagation();}},true);
// Debounce disk writes; flush before backgrounding and page switches.
document.addEventListener('input',()=>{clearTimeout(draftTimer);draftTimer=setTimeout(()=>persistPageDraft(),350);});
document.addEventListener('change',()=>persistPageDraft());
document.addEventListener('visibilitychange',()=>{if(document.hidden)persistPageDraft();});
window.addEventListener('pagehide',()=>persistPageDraft());
const originalRoute=renderAppPageFromHistory;
renderAppPageFromHistory=function(){const next=history.state?.appPage||'main';if(next!==activeDraftPage)persistPageDraft(activeDraftPage);originalRoute();activeDraftPage=next;};
// Baselines must be captured after each form has populated.
for(const name of ['loadDate','loadDetailSettlement','setupDocumentEditor','loadBusinessProfileForm']){
 const original=window[name];window[name]=function(...args){const result=original.apply(this,args);const page={loadDate:'main',loadDetailSettlement:'detailsettlement',setupDocumentEditor:'documenteditor',loadBusinessProfileForm:'documenthub'}[name];pageBaselines[page]=formState(page);return result;};
}
for(const name of ['newBusinessDocument','editBusinessDocument','openDetailSettlement','openDocumentHub']){
 const original=window[name];window[name]=function(...args){persistPageDraft();const result=original.apply(this,args);const page=history.state?.appPage;setTimeout(()=>offerDraft(page),30);return result;};
}
// Also save add/remove row actions, which do not emit input events.
document.addEventListener('click',()=>setTimeout(()=>persistPageDraft(),0));
pageBaselines.main=formState('main');
// Migrate legacy supplier snapshots once; historical information cannot be reconstructed.
try{const docs=getBusinessDocs();if(docs.some(d=>!d.supplier||!validDocumentId(d.id)))saveBusinessDocsArray(sanitizeBusinessDocs(docs));}catch(e){console.error('document migration',e);}
setTimeout(()=>{
 const damaged=storageRecoveryWarnings.length||Object.keys(localStorage).some(k=>k.startsWith('recovery_warning_'));
 if(damaged)showAppMessage('저장 데이터 일부를 읽지 못했어요. 원본은 복구용으로 보관했습니다. 설정 → 백업에서 복구용 원본을 저장하거나 정상 백업을 불러와주세요.');
 else offerDraft('main');
},350);
function showSavedFileActions(kind){
 showBackupToast(kind+'를 다운로드 폴더에 저장했어요.');
 let bar=$('savedFileActions');if(!bar){bar=document.createElement('div');bar.id='savedFileActions';bar.className='saved-file-actions';document.body.appendChild(bar);}
 bar.innerHTML='<span>'+escapeHtml(kind)+' 저장 완료</span><button onclick="Android.openLatestExport()">열기</button><button onclick="Android.shareLatestExport()">공유</button><button onclick="this.parentElement.remove()" aria-label="닫기">×</button>';
}
onNativePdfSaved=()=>showSavedFileActions('PDF');onNativeImageSaved=()=>showSavedFileActions('이미지');
// Protect changing the selected day as well as changing pages.
for(const name of ['selectDate','moveMonth']){const original=window[name];window[name]=function(...args){if((history.state?.appPage||'main')==='main'&&guardUnsavedBack(()=>original.apply(this,args)))return;return original.apply(this,args);};}
// Keep a failed save from leaving in-memory totals ahead of disk data.
for(const name of ['saveRecord','saveDetailSettlement','saveTarget','addEmployee','saveEmployeeEdit']){
 const original=window[name];window[name]=function(...args){const before={records:JSON.parse(JSON.stringify(records)),detailRecords:JSON.parse(JSON.stringify(detailRecords)),employees:JSON.parse(JSON.stringify(employees)),targets:JSON.parse(JSON.stringify(targets))};const disk=storageSnapshot();try{return original.apply(this,args);}catch(e){records=before.records;detailRecords=before.detailRecords;employees=before.employees;targets=before.targets;try{writeSnapshot(disk);}catch(ignore){}showAppMessage('저장하지 못했어요. 백업 후 저장 공간을 확인해주세요.');return false;}};
}

function runDataTransaction(action){
 const memory={records:JSON.parse(JSON.stringify(records)),detailRecords:JSON.parse(JSON.stringify(detailRecords)),employees:JSON.parse(JSON.stringify(employees)),targets:JSON.parse(JSON.stringify(targets))};const disk=storageSnapshot();
 try{return action();}catch(e){records=memory.records;detailRecords=memory.detailRecords;employees=memory.employees;targets=memory.targets;try{writeSnapshot(disk);}catch(ignore){}throw e;}
}

onNativeFileSaved=()=>{setMonthlyExcelSaving(false);showSavedFileActions('엑셀 파일');};

const originalTodaySync=syncCalendarToToday;
syncCalendarToToday=function(force=false){if(pageBaselines.main&&!draftEqual(formState('main'),pageBaselines.main)){persistPageDraft('main');return;}return originalTodaySync(force);};
