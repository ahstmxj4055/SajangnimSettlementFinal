/* Documents and Excel module — v126 */

const BUSINESS_PROFILE_KEY='sajangnim_business_profile';
const BUSINESS_DOCS_KEY='sajangnim_business_docs';
let docEditorType='quote';
let docEditorId=null;
let previewDocumentId=null;
let docSupplierSnapshot=null;

function docEl(id){
  const el=document.getElementById(id);
  if(!el) throw new Error(`문서 화면 요소를 찾을 수 없습니다: ${id}`);
  return el;
}

function getBusinessProfile(){try{return readStoredJson(BUSINESS_PROFILE_KEY,{})||{}}catch(e){return {}}}
function getBusinessDocs(){try{const a=readStoredJson(BUSINESS_DOCS_KEY,[]);return Array.isArray(a)?a:[]}catch(e){return []}}
function sanitizeBusinessProfile(p){p=(p&&typeof p==='object')?p:{};return {name:String(p.name||''),owner:String(p.owner||''),number:String(p.number||''),phone:String(p.phone||''),address:String(p.address||''),email:String(p.email||'')}}
function sanitizeBusinessDocs(arr){return (Array.isArray(arr)?arr:[]).filter(x=>x&&typeof x==='object').map(x=>({id:validDocumentId(x.id)?String(x.id):newDocumentId(),supplier:sanitizeBusinessProfile(x.supplier||getBusinessProfile()),type:x.type==='statement'?'statement':'quote',number:String(x.number||''),date:String(x.date||localToday()),client:{name:String(x.client?.name||''),bizNo:String(x.client?.bizNo||''),phone:String(x.client?.phone||''),address:String(x.client?.address||'')},items:(Array.isArray(x.items)?x.items:[]).map(i=>({name:String(i?.name||''),qty:Math.max(0,Number(i?.qty)||0),unitPrice:Math.max(0,Number(i?.unitPrice)||0)})).filter(i=>i.name||i.qty||i.unitPrice),vatMode:['separate','included','none'].includes(x.vatMode)?x.vatMode:'separate',memo:String(x.memo||''),createdAt:String(x.createdAt||new Date().toISOString()),updatedAt:String(x.updatedAt||new Date().toISOString())}))}
function saveBusinessDocsArray(a){localStorage.setItem(BUSINESS_DOCS_KEY,JSON.stringify(a))}
function openDocumentHub(mode){history.pushState({appPage:'documenthub'},'','#documents');renderAppPageFromHistory();loadBusinessProfileForm();renderBusinessDocumentList();if(mode==='quote'||mode==='statement'){/* launcher intent only; hub stays visible */}}
function backFromDocumentHub(){if(history.state?.appPage==='documenthub')history.back();else{history.replaceState({appPage:'main'},'',location.pathname);renderAppPageFromHistory()}}
function loadBusinessProfileForm(){const p=sanitizeBusinessProfile(getBusinessProfile());[['bizName','name'],['bizOwner','owner'],['bizNumber','number'],['bizPhone','phone'],['bizAddress','address'],['bizEmail','email']].forEach(([id,k])=>{const el=document.getElementById(id);if(el)el.value=p[k]||''})}
function saveBusinessProfile(){
  try{
    const p={
      name:docEl('bizName').value.trim(),
      owner:docEl('bizOwner').value.trim(),
      number:docEl('bizNumber').value.trim(),
      phone:docEl('bizPhone').value.trim(),
      address:docEl('bizAddress').value.trim(),
      email:docEl('bizEmail').value.trim()
    };
    localStorage.setItem(BUSINESS_PROFILE_KEY,JSON.stringify(p));
    markPageSaved('documenthub');showBackupToast('사업자 정보를 저장했어요.');
  }catch(e){
    console.error(e);
    showAppMessage('사업자 정보를 저장하지 못했습니다.');
  }
}
function renderBusinessDocumentList(){
 const el=document.getElementById('businessDocList');if(!el)return;
 const query=(document.getElementById('docSearch')?.value||'').trim().toLowerCase();
 const month=document.getElementById('docFilterMonth')?.value||'';
 const all=getBusinessDocs().sort((a,b)=>(b.updatedAt||'').localeCompare(a.updatedAt||''));
 const filtered=all.filter(d=>(!month||d.date?.startsWith(month))&&(!query||[d.client?.name,d.number,d.type==='quote'?'견적서':'거래명세서'].join(' ').toLowerCase().includes(query)));
 const count=document.getElementById('docResultCount');if(count)count.textContent=`전체 ${all.length}건 · 검색 ${filtered.length}건`;
 const limit=window.documentListLimit||20;
 el.innerHTML=filtered.slice(0,limit).map(d=>{const t=calcBusinessDocTotals(d);return `<div class="doc-list-item"><div><b>${d.type==='quote'?'📄 견적서':'🧾 거래명세서'} · ${escapeHtml(d.client?.name||'거래처 미입력')}</b><small>${escapeHtml(d.number||'')} · ${escapeHtml(d.date||'')} · ${money(t.total)}</small></div><div class="doc-list-actions"><button data-doc-id="${escapeHtml(d.id)}" onclick="editBusinessDocument(this.dataset.docId)">열기</button><button data-doc-id="${escapeHtml(d.id)}" onclick="deleteBusinessDocument(this.dataset.docId)">삭제</button></div></div>`}).join('')||'<p class="muted">표시할 문서가 없어요.</p>';
 if(filtered.length>limit)el.insertAdjacentHTML('beforeend','<button style="width:100%" onclick="window.documentListLimit=(window.documentListLimit||20)+20;renderBusinessDocumentList()">20개 더 보기</button>');
}
function nextDocNumber(type){
 const prefix=type==='quote'?'Q':'T',day=localToday().replaceAll('-',''),base=`${prefix}-${day}-`;
 const key='sajangnim_doc_sequence_'+base;
 const max=getBusinessDocs().reduce((m,d)=>d.number?.startsWith(base)?Math.max(m,Number(d.number.slice(base.length))||0):m,0);
 const n=Math.max(max,Number(localStorage.getItem(key))||0)+1;
 localStorage.setItem(key,String(n));return base+String(n).padStart(2,'0');
}
function newBusinessDocument(type){docEditorType=type==='statement'?'statement':'quote';docEditorId=null;history.pushState({appPage:'documenteditor'},'','#document-editor');renderAppPageFromHistory();setupDocumentEditor(null)}
function editBusinessDocument(id){const d=getBusinessDocs().find(x=>x.id===id);if(!d)return;docEditorType=d.type;docEditorId=d.id;history.pushState({appPage:'documenteditor'},'','#document-editor');renderAppPageFromHistory();setupDocumentEditor(d)}
function setupDocumentEditor(d){
  try{
    docSupplierSnapshot=sanitizeBusinessProfile(d?.supplier||getBusinessProfile());
    docEl('docEditorTitle').textContent=docEditorType==='quote'?'견적서':'거래명세서';
    docEl('convertStatementBtn').style.display=docEditorType==='quote'?'block':'none';
    docEl('docNumber').value=d?.number||nextDocNumber(docEditorType);
    docEl('docDate').value=d?.date||localToday();
    docEl('docClientName').value=d?.client?.name||'';
    docEl('docClientBizNo').value=d?.client?.bizNo||'';
    docEl('docClientPhone').value=d?.client?.phone||'';
    docEl('docClientAddress').value=d?.client?.address||'';
    docEl('docVatMode').value=d?.vatMode||'separate';
    docEl('docMemo').value=d?.memo||'';docEl('docMemoEnabled').checked=!!(d?.memo);toggleDocumentMemo();
    docEl('docItemRows').innerHTML='';
    const items=d?.items?.length?d.items:[{name:'',qty:1,unitPrice:0}];
    items.forEach(addDocumentItem);
    updateDocumentTotals();
  }catch(e){
    console.error('setupDocumentEditor',e);
    showAppMessage('문서 작성 화면을 불러오지 못했습니다.');
  }
}
function backFromDocumentEditor(){if(history.state?.appPage==='documenteditor')history.back();else openDocumentHub()}
function addDocumentItem(item={name:'',qty:1,unitPrice:0}){
  const row=document.createElement('div');
  row.className='doc-item-row';
  row.innerHTML=`<input class="doc-item-name" placeholder="품목명" value="${escapeHtml(item.name||'')}">
    <input class="doc-item-qty" inputmode="decimal" value="${Number.isFinite(Number(item.qty))?Number(item.qty):1}" min="0" oninput="updateDocumentTotals()">
    <input class="doc-item-price money" inputmode="numeric" value="${moneyInput(Number(item.unitPrice)||0)}" oninput="this.value=moneyInput(num(this.value));updateDocumentTotals()">
    <button type="button" onclick="this.parentElement.remove();updateDocumentTotals()">×</button>`;
  docEl('docItemRows').appendChild(row);
}
function collectDocumentItems(){return [...document.querySelectorAll('#docItemRows .doc-item-row')].map(r=>({name:r.querySelector('.doc-item-name').value.trim(),qty:Math.max(0,Number(String(r.querySelector('.doc-item-qty').value).replace(',','.'))||0),unitPrice:Math.max(0,num(r.querySelector('.doc-item-price').value))})).filter(i=>i.name||i.qty||i.unitPrice)}
function calcBusinessDocTotals(d){const base=(d.items||[]).reduce((s,i)=>s+(Number(i.qty)||0)*(Number(i.unitPrice)||0),0);let supply=base,vat=0,total=base;if(d.vatMode==='included'){total=Math.round(base);supply=Math.round(total/1.1);vat=total-supply}else if(d.vatMode==='separate'){supply=Math.round(base);vat=Math.round(supply*.1);total=supply+vat}else{supply=Math.round(base);total=supply}return {supply,vat,total}}
function toggleDocumentMemo(){const e=docEl('docMemoEnabled'),w=docEl('docMemoWrap');if(e&&w)w.classList.toggle('hidden',!e.checked)}
function currentDocumentDraft(){
  return {
    id:docEditorId||newDocumentId(),
    supplier:JSON.parse(JSON.stringify(docSupplierSnapshot||sanitizeBusinessProfile(getBusinessProfile()))),
    type:docEditorType,
    number:docEl('docNumber').value.trim()||nextDocNumber(docEditorType),
    date:docEl('docDate').value||localToday(),
    client:{
      name:docEl('docClientName').value.trim(),
      bizNo:docEl('docClientBizNo').value.trim(),
      phone:docEl('docClientPhone').value.trim(),
      address:docEl('docClientAddress').value.trim()
    },
    items:collectDocumentItems(),
    vatMode:docEl('docVatMode').value,
    memo:docEl('docMemoEnabled').checked?docEl('docMemo').value.trim():'',
    updatedAt:new Date().toISOString()
  };
}
function updateDocumentTotals(){
  try{
    const t=calcBusinessDocTotals(currentDocumentDraft());
    docEl('docSupplyTotal').textContent=money(t.supply);
    docEl('docVatTotal').textContent=money(t.vat);
    docEl('docGrandTotal').textContent=money(t.total);
  }catch(e){
    console.error('updateDocumentTotals',e);
  }
}
function saveBusinessDocument(){
 const d=currentDocumentDraft();if(!validateDocumentDraft(d))return false;
 if(getBusinessDocs().some(x=>x.id!==d.id&&x.number===d.number)){showAppMessage('이미 사용 중인 문서번호예요. 다른 번호를 입력해주세요.');return false;}
 try{let docs=getBusinessDocs();const old=docs.find(x=>x.id===d.id);d.createdAt=old?.createdAt||new Date().toISOString();saveBusinessDocsArray([d,...docs.filter(x=>x.id!==d.id)]);docEditorId=d.id;markPageSaved('documenteditor');showBackupToast('문서를 저장했어요.');renderBusinessDocumentList();return true;}
 catch(e){showAppMessage('문서를 저장하지 못했어요. 저장 공간을 확인하고 백업해주세요.');return false;}
}
function deleteBusinessDocument(id){openAppModal('이 문서를 삭제할까요?',{confirmText:'삭제',showCancel:true,danger:true,onConfirm:()=>{saveBusinessDocsArray(getBusinessDocs().filter(x=>x.id!==id));renderBusinessDocumentList();showBackupToast('문서를 삭제했어요.')}})}
function convertQuoteToStatement(){
 if(docEditorType!=='quote')return;const src=currentDocumentDraft();if(!validateDocumentDraft(src))return;
 try{const d={...src,id:newDocumentId(),type:'statement',number:nextDocNumber('statement'),date:localToday(),createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};saveBusinessDocsArray([d,...getBusinessDocs()]);docEditorType='statement';docEditorId=d.id;setupDocumentEditor(d);markPageSaved('documenteditor');showBackupToast('거래명세서로 변환했어요.');}catch(e){showAppMessage('문서를 저장하지 못했어요.');}
}
function savePreviewDraft(d){
  const copy=JSON.parse(JSON.stringify(d));
  window.__docPreviewDraft=copy;
  try{sessionStorage.setItem('sajangnim_doc_preview',JSON.stringify(copy));}catch(e){}
  try{localStorage.setItem('sajangnim_doc_preview_fallback',JSON.stringify(copy));}catch(e){}
}
function getPreviewDraft(){
  if(window.__docPreviewDraft) return window.__docPreviewDraft;
  try{
    const s=sessionStorage.getItem('sajangnim_doc_preview');
    if(s){window.__docPreviewDraft=JSON.parse(s);return window.__docPreviewDraft;}
  }catch(e){}
  try{
    const s=localStorage.getItem('sajangnim_doc_preview_fallback');
    if(s){window.__docPreviewDraft=JSON.parse(s);return window.__docPreviewDraft;}
  }catch(e){}
  return null;
}
function previewCurrentDocument(){
  try{
    const d=currentDocumentDraft();
    if(!validateDocumentDraft(d))return;
    previewDocumentId=d.id;
    savePreviewDraft(d);
    history.pushState({appPage:'documentpreview'},'','#document-preview');
    renderAppPageFromHistory();

    const draw=()=>{
      try{
        const draft=getPreviewDraft();
        if(!draft) throw new Error('preview draft missing');
        renderDocumentPrint(draft);
      }catch(e){
        console.error('document preview error',e);
        const paper=document.getElementById('documentPrintPaper');
        if(paper) paper.innerHTML='<div style="padding:20px;color:#b91c1c;font-weight:800">미리보기를 불러오지 못했습니다.<br>수정하기로 돌아갔다가 다시 시도해주세요.</div>';
      }
    };
    draw();
    setTimeout(draw,80);
    setTimeout(draw,220);
  }catch(e){
    console.error('previewCurrentDocument',e);
    showAppMessage('미리보기를 만들지 못했습니다.');
  }
}
function backFromDocumentPreview(){
  if(history.state?.appPage==='documentpreview')history.back();
  else{
    history.replaceState({appPage:'documenteditor'},'','#document-editor');
    renderAppPageFromHistory();
  }
}
function buildDocumentPrintHtml(d){
  d=d||{};
  const p=sanitizeBusinessProfile(d.supplier||getBusinessProfile());
  const t=calcBusinessDocTotals(d);
  const title=d.type==='quote'?'견 적 서':'거 래 명 세 서';
  const rows=(Array.isArray(d.items)?d.items:[]).map((i,idx)=>`
    <tr>
      <td>${idx+1}</td>
      <td>${escapeHtml(i?.name||'')}</td>
      <td class="print-money">${Number(i?.qty||0).toLocaleString('ko-KR')}</td>
      <td class="print-money">${Number(i?.unitPrice||0).toLocaleString('ko-KR')}</td>
      <td class="print-money">${Math.round(Number(i?.qty||0)*Number(i?.unitPrice||0)).toLocaleString('ko-KR')}</td>
    </tr>`).join('');

  return `<div class="print-doc-title">${title}</div>
    <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:10px">
      <span>문서번호: ${escapeHtml(d.number||'')}</span>
      <span>작성일: ${escapeHtml(d.date||'')}</span>
    </div>
    <div class="print-meta">
      <div class="print-box"><b>공급자</b><br>
        상호: ${escapeHtml(p.name||'-')}<br>
        대표자: ${escapeHtml(p.owner||'-')}<br>
        사업자번호: ${escapeHtml(p.number||'-')}<br>
        주소: ${escapeHtml(p.address||'-')}<br>
        연락처: ${escapeHtml(p.phone||'-')}
      </div>
      <div class="print-box"><b>공급받는 자</b><br>
        거래처: ${escapeHtml(d.client?.name||'-')}<br>
        사업자번호: ${escapeHtml(d.client?.bizNo||'-')}<br>
        주소: ${escapeHtml(d.client?.address||'-')}<br>
        연락처: ${escapeHtml(d.client?.phone||'-')}
      </div>
    </div>
    <table class="print-table">
      <thead><tr><th>No</th><th>품목</th><th>수량</th><th>단가</th><th>금액</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <div class="print-total">
      <div><span>공급가액</span><b>${money(t.supply)}</b></div>
      <div><span>부가세</span><b>${money(t.vat)}</b></div>
      <div class="grand"><span>합계금액</span><b>${money(t.total)}</b></div>
    </div>
    ${d.memo?.trim()?`<div class="print-note"><b>비고</b><br>${escapeHtml(d.memo)}</div>`:''}`;
}
function renderDocumentPrint(d){
  const paper=document.getElementById('documentPrintPaper');
  if(!paper) throw new Error('documentPrintPaper not found');
  paper.innerHTML=buildDocumentPrintHtml(d);
}
function buildStandalonePrintPage(d){
  const body=buildDocumentPrintHtml(d);
  return `<!doctype html><html lang="ko"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style>
      *{box-sizing:border-box}body{margin:0;padding:12mm;background:#fff;color:#111;font-family:Arial,'Noto Sans KR',sans-serif}
      .print-doc-title{text-align:center;font-size:26px;font-weight:900;letter-spacing:5px;margin:5px 0 22px}
      .print-meta{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:18px}
      .print-box{border:1px solid #333;padding:10px;font-size:11px;line-height:1.65}.print-box b{font-size:12px}
      .print-table{width:100%;border-collapse:collapse;font-size:10px}.print-table th,.print-table td{border:1px solid #555;padding:7px 5px}
      .print-table th{background:#f2f2f2}.print-money{text-align:right}
      .print-total{margin-top:15px;margin-left:auto;width:55%;font-size:11px}.print-total div{display:flex;justify-content:space-between;padding:5px;border-bottom:1px solid #ddd}
      .print-total .grand{font-size:15px;font-weight:900;border-top:2px solid #111;border-bottom:0;margin-top:4px}
      .print-note{margin-top:18px;border:1px solid #999;padding:10px;min-height:45px;font-size:10px;white-space:pre-wrap}
      @page{size:A4;margin:8mm}
    </style></head><body>${body}</body></html>`;
}
function closeDocumentShareDialog(){
  const dialog=document.getElementById('documentShareDialog');
  if(dialog){dialog.remove();return true;}
  return false;
}
function openDocumentShareDialog(){
  const d=getPreviewDraft();
  if(!d){showBackupToast('미리보기 문서를 다시 열어주세요.');return;}
  closeDocumentShareDialog();
  const overlay=document.createElement('div');overlay.id='documentShareDialog';
  overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999999;display:flex;align-items:center;justify-content:center;padding:20px';
  overlay.innerHTML='<div class="share-dialog-card" style="width:100%;max-width:340px;background:#fff;color:#111827;border-radius:18px;padding:22px;box-shadow:0 10px 35px #0003"><h3 style="margin:0 0 14px;font-size:18px">문서 공유하기</h3><button type="button" class="share-dialog-action" data-share="pdf" style="display:block;width:100%;padding:15px;margin-bottom:9px;border:0;border-radius:11px;background:#e5e7eb;color:#111827;font-weight:800">PDF로 공유</button><button type="button" class="share-dialog-action" data-share="png" style="display:block;width:100%;padding:15px;margin-bottom:9px;border:0;border-radius:11px;background:#e5e7eb;color:#111827;font-weight:800">이미지로 공유</button><button type="button" class="share-dialog-cancel" data-share="cancel" style="display:block;width:100%;padding:12px;border:0;border-radius:11px;background:#f3f4f6;color:#374151">취소</button></div>';
  overlay.addEventListener('click',e=>{
    const b=e.target.closest('[data-share]');if(!b){if(e.target===overlay)closeDocumentShareDialog();return;}
    const format=b.dataset.share;closeDocumentShareDialog();if(format==='cancel')return;
    const title=(d.type==='quote'?'견적서_':'거래명세서_')+(d.number||localToday());
    if(window.Android&&typeof Android.shareHtmlDocument==='function'){
      Android.shareHtmlDocument(buildStandalonePrintPage(d),title+(format==='pdf'?'.pdf':'.png'),format);
      showBackupToast('공유 파일을 준비하고 있어요.');
    }else showAppMessage('Android 앱에서 공유 기능을 사용할 수 있어요.');
  });
  document.body.appendChild(overlay);
}
function onNativeShareFailed(){showAppMessage('공유 파일을 만들지 못했어요. 다시 시도해주세요.');}
function saveCurrentBusinessDocumentPdf(){
  const d=getPreviewDraft();
  if(!d){showBackupToast('미리보기 문서를 다시 열어주세요.');return}
  const title=(d.type==='quote'?'견적서_':'거래명세서_')+(d.number||localToday());
  try{
    if(window.Android&&typeof Android.saveHtmlAsPdf==='function'){
      Android.saveHtmlAsPdf(buildStandalonePrintPage(d),title+'.pdf');
      showBackupToast('PDF를 저장하고 있어요.');
      return;
    }
  }catch(e){console.error('PDF save error',e);}
  showAppMessage('PDF 저장은 최신 Android 앱에서 지원합니다.');
}

function saveCurrentBusinessDocumentImage(){
  const d=getPreviewDraft();
  if(!d){showBackupToast('미리보기 문서를 다시 열어주세요.');return}
  try{renderDocumentPrint(d)}catch(e){}
  const title=(d.type==='quote'?'견적서_':'거래명세서_')+(d.number||localToday());
  const html=buildStandalonePrintPage(d);

  try{
    if(window.Android&&typeof Android.saveHtmlAsImage==='function'){
      Android.saveHtmlAsImage(html,title+'.png');
      showBackupToast('이미지를 만들고 있어요.');
      return;
    }
  }catch(e){
    console.error('native image save error',e);
  }
  showAppMessage('이 기기에서는 이미지 저장을 사용할 수 없습니다.');
}

function openExcelMonthPicker(){
 const input=document.getElementById('excelMonth');if(!input)return;
 try{if(typeof input.showPicker==='function'){input.showPicker();return;}}catch(e){console.warn('month showPicker fallback',e)}
 input.focus();try{input.click()}catch(e){}
}
function openMonthlyExcelPage(){
  history.pushState({appPage:'monthlyexcel'},'','#monthly-excel');
  renderAppPageFromHistory();
  const now=new Date();
  docEl('excelMonth').value=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
  renderExcelPreview();
}
function backFromMonthlyExcel(){if(history.state?.appPage==='monthlyexcel')history.back();else{history.replaceState({appPage:'main'},'',location.pathname);renderAppPageFromHistory()}}
function monthRecords(key){return records.filter(r=>String(r.date||'').startsWith(key)).sort((a,b)=>a.date.localeCompare(b.date))}
function renderExcelPreview(){
  const key=docEl('excelMonth').value;
  if(!key)return;
  const rs=monthRecords(key);
  const sales=rs.reduce((s,r)=>s+Number(r.sales||0),0);
  const expense=rs.reduce((s,r)=>s+Number(r.expense||0),0);
  const pay=rs.reduce((s,r)=>s+Number(r.pay||0),0);
  const profit=rs.reduce((s,r)=>s+Number(r.profit||0),0);
  docEl('excelSummary').innerHTML=`<div><small>총매출</small><b>${money(sales)}</b></div><div><small>총지출+급여</small><b>${money(expense+pay)}</b></div><div><small>순수익</small><b>${money(profit)}</b></div>`;
}
function monthlyEmployeeRows(key){const map={};Object.entries(detailRecords||{}).filter(([d])=>d.startsWith(key)).forEach(([date,det])=>{(det.employees||[]).filter(x=>x.checked).forEach(x=>{const k=x.id||x.name;if(!map[k])map[k]={name:x.name||'직원',days:0,pay:0};map[k].days++;map[k].pay+=Number(x.pay)||0});(det.dailyWorkers||[]).forEach(x=>{const k='daily_'+x.name;if(!map[k])map[k]={name:x.name||'일일알바',days:0,pay:0};map[k].days++;map[k].pay+=Number(x.pay)||0})});return Object.values(map)}
function monthlyDetailColumns(date){const d=detailRecords?.[date];if(!d)return [0,0,0,0,0,0,0,0,0,0,0];const s=d.sales||{},e=d.expense||{};return [Number(s.cash)||0,Number(s.card)||0,Number(s.transfer)||0,Number(s.platform)||0,Number(s.other)||0,Number(e.material)||0,Number(e.rent)||0,Number(e.utility)||0,Number(e.platformFee)||0,Number(e.cardFee)||0,Number(e.other)||0]}
let monthlyExcelSaving=false;
function setMonthlyExcelSaving(busy){
 monthlyExcelSaving=busy;
 const b=document.getElementById('monthlyExcelExportButton');
 if(b){b.disabled=busy;b.setAttribute('aria-busy',String(busy));}
}
function exportMonthlyXlsx(){
 if(monthlyExcelSaving)return;
 setMonthlyExcelSaving(true);
 try{exportMonthlyXlsxCore()}catch(e){console.error('Excel export failed',e);setMonthlyExcelSaving(false);showBackupToast('엑셀 파일 생성에 실패했어요.');}
}
function exportMonthlyXlsxCore(){const key=docEl('excelMonth').value;if(!key){setMonthlyExcelSaving(false);showBackupToast('월을 선택해주세요.');return}const rs=monthRecords(key);const sales=rs.reduce((s,r)=>s+Number(r.sales||0),0),expense=rs.reduce((s,r)=>s+Number(r.expense||0),0),pay=rs.reduce((s,r)=>s+Number(r.pay||0),0),profit=rs.reduce((s,r)=>s+Number(r.profit||0),0),target=Number(targets?.[key])||0;const summary=[['사장님 정산 월간 리포트',key],['항목','금액'],['총매출',sales],['지출',expense],['직원급여',pay],['총지출+급여',expense+pay],['순수익',profit],['목표매출',target],['달성률',target?Math.round(sales/target*10000)/100:0],['정산일수',rs.length]];const daily=[['날짜','매출','지출','직원급여','순수익','현금','카드','계좌이체','배달·플랫폼','기타매출','재료비','임대료','공과금','플랫폼수수료','카드수수료','기타지출','메모']];rs.forEach(r=>daily.push([r.date,Number(r.sales)||0,Number(r.expense)||0,Number(r.pay)||0,Number(r.profit)||0,...monthlyDetailColumns(r.date),r.memo||'']));const emp=[['직원명','근무일수','급여합계'],...monthlyEmployeeRows(key).map(x=>[x.name,x.days,x.pay])];const prettySummary=[['월간 정산 보고서'],[key.replace('-','년 ')+'월 결산'],[],['핵심 지표','금액'],['총매출',sales],['총지출 + 급여',expense+pay],['순수익',profit],['목표매출',target],['달성률',target?Math.round(sales/target*10000)/100:0],['정산일수',rs.length],[],['세부 내역','금액'],['지출',expense],['직원급여',pay],['총지출 + 급여',expense+pay],['순수익',profit]];
const prettyDaily=[['일별 정산 내역'],[key.replace('-','년 ')+'월'],...daily];
const prettyEmp=[['직원 급여 내역'],[key.replace('-','년 ')+'월'],...emp,['합계',emp.slice(1).reduce((n,r)=>n+Number(r[1]||0),0),emp.slice(1).reduce((n,r)=>n+Number(r[2]||0),0)]];
const bytes=makeSimpleXlsx([{name:'월간요약',rows:prettySummary,kind:'summary'},{name:'일별정산',rows:prettyDaily,kind:'daily'},{name:'직원급여',rows:prettyEmp,kind:'employee'}]);const b64=uint8ToBase64(bytes);const fileName=`사장님정산_${key}_월간리포트.xlsx`;try{if(window.Android&&typeof Android.saveBase64File==='function'){Android.saveBase64File(b64,fileName,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');return}}catch(e){console.error('Native Excel save failed',e)}const blob=new Blob([bytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=fileName;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);setMonthlyExcelSaving(false);showBackupToast('엑셀 파일 다운로드를 요청했어요.')}
function onNativePdfSaved(name){showBackupToast('PDF가 다운로드 폴더에 저장됐어요.')}
function onNativePdfFailed(){showAppMessage('PDF 저장에 실패했어요. 다시 시도해주세요.')}
function onNativeImageSaved(name){showBackupToast('이미지가 다운로드 폴더에 저장됐어요.')}
function onNativeImageFailed(){showAppMessage('이미지 저장에 실패했어요. 다시 시도해주세요.')}
function onNativeFileSaved(name){setMonthlyExcelSaving(false);showBackupToast('파일을 다운로드 폴더에 저장했어요.')}
function onNativeFileFailed(){setMonthlyExcelSaving(false);showBackupToast('파일 저장에 실패했어요.')}
function uint8ToBase64(u8){let s='',chunk=0x8000;for(let i=0;i<u8.length;i+=chunk)s+=String.fromCharCode(...u8.subarray(i,Math.min(i+chunk,u8.length)));return btoa(s)}
function xmlEsc(v){return String(v??'').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff]/g,'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]))}
function colName(n){let s='';while(n){n--;s=String.fromCharCode(65+n%26)+s;n=Math.floor(n/26)}return s}
function sheetXml(rows,kind){
const summary=kind==='summary',daily=kind==='daily',head=summary?4:3;
const widths=summary?[28,24]:daily?[19,18,18,18,18,18,18,18,20,18,18,18,18,20,18,18,32]:[22,16,23];
let out='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
out+=`<sheetViews><sheetView workbookViewId="0" showGridLines="0"/></sheetViews>`;
out+=`<sheetFormatPr defaultRowHeight="24"/><cols>${widths.map((v,i)=>`<col min="${i+1}" max="${i+1}" width="${v}" customWidth="1"/>`).join('')}</cols><sheetData>`;
rows.forEach((row,i)=>{const r=i+1,header=summary?[4,12].includes(r):r===3,total=kind==='employee'&&r===rows.length;
out+=`<row r="${r}" ht="${r===1?38:header?30:26}" customHeight="1">`;
row.forEach((v,j)=>{const ref=colName(j+1)+r,num=typeof v==='number'&&Number.isFinite(v);
let style=r===1?1:header?2:total?(num&&j===1?11:num?6:3):summary&&[5,6,7,8,9,10,13,14,15,16].includes(r)?(num?(r===9?5:r===10?11:4):3):num?(kind==='employee'&&j===1?11:7):(r%2?8:9);
out+=num?`<c r="${ref}" s="${style}" t="n"><v>${v}</v></c>`:`<c r="${ref}" s="${style}" t="inlineStr"><is><t>${xmlEsc(v)}</t></is></c>`;});
out+='</row>';});
out+='</sheetData>';


out+='</worksheet>';return out;
}
function excelStylesXml(){return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="2"><numFmt numFmtId="164" formatCode="#,##0&quot;원&quot;;[Red]-#,##0&quot;원&quot;"/><numFmt numFmtId="165" formatCode="0.00&quot;%&quot;"/></numFmts>
<fonts count="4"><font><sz val="11"/><name val="Malgun Gothic"/></font><font><b/><sz val="17"/><color rgb="FFFFFFFF"/><name val="Malgun Gothic"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Malgun Gothic"/></font><font><b/><sz val="12"/><color rgb="FF047857"/><name val="Malgun Gothic"/></font></fonts>
<fills count="5"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF17243A"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FF35547B"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF1F5F9"/></patternFill></fill></fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left/><right/><top/><bottom style="thin"><color rgb="FFE2E8F0"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="12">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0"/>
<xf numFmtId="164" fontId="3" fillId="4" borderId="1" xfId="0"/>
<xf numFmtId="165" fontId="3" fillId="4" borderId="1" xfId="0"/>
<xf numFmtId="164" fontId="3" fillId="4" borderId="1" xfId="0"/>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0"/>
<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0"/><xf numFmtId="0" fontId="3" fillId="4" borderId="1" xfId="0"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`}
function makeSimpleXlsx(sheets){const files=[];const add=(name,text)=>files.push({name,data:new TextEncoder().encode(text)});add('[Content_Types].xml',`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${sheets.map((_,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`);add('_rels/.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');add('xl/styles.xml',excelStylesXml());add('xl/workbook.xml',`<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.map((s,i)=>`<sheet name="${xmlEsc(s.name)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join('')}</sheets></workbook>`);add('xl/_rels/workbook.xml.rels',`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join('')}${`<Relationship Id="rId${sheets.length+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>`}</Relationships>`);sheets.forEach((s,i)=>add(`xl/worksheets/sheet${i+1}.xml`,sheetXml(s.rows,s.kind)));return zipStore(files)}
const CRC_TABLE=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})();
function crc32(data){let c=0xffffffff;for(const b of data)c=CRC_TABLE[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0}
function u16(n){return [n&255,(n>>>8)&255]}function u32(n){return [n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]}
function zipStore(files){let parts=[],central=[],offset=0;for(const f of files){const name=new TextEncoder().encode(f.name),data=f.data,crc=crc32(data);const local=new Uint8Array([80,75,3,4,20,0,0,8,0,0,0,0,0,0,...u32(crc),...u32(data.length),...u32(data.length),...u16(name.length),0,0,...name]);parts.push(local,data);const cent=new Uint8Array([80,75,1,2,20,0,20,0,0,8,0,0,0,0,0,0,...u32(crc),...u32(data.length),...u32(data.length),...u16(name.length),0,0,0,0,0,0,0,0,0,0,0,0,...u32(offset),...name]);central.push(cent);offset+=local.length+data.length}const centralSize=central.reduce((s,x)=>s+x.length,0),end=new Uint8Array([80,75,5,6,0,0,0,0,...u16(files.length),...u16(files.length),...u32(centralSize),...u32(offset),0,0]),total=parts.reduce((s,x)=>s+x.length,0)+centralSize+end.length,out=new Uint8Array(total);let p=0;for(const x of parts){out.set(x,p);p+=x.length}for(const x of central){out.set(x,p);p+=x.length}out.set(end,p);return out}

if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{loadBusinessProfileForm();renderBusinessDocumentList()});else{loadBusinessProfileForm();renderBusinessDocumentList()}
