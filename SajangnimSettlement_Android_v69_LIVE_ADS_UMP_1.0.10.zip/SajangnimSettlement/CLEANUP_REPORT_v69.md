# v69 출시 전 변경 보고서

## 기준
- v68 1.0.9 / versionCode 10
- v69 1.0.10 / versionCode 11

## 변경
- 테스트 AdMob 배너 -> 실제 하단 배너 광고 단위
- UMP 4.0.0 추가
- UMP 동의 완료/기존 유효 동의 확인 후에만 광고 요청
- 광고 개인정보 설정 재진입 처리 추가
- 앱 내 개인정보처리방침 AdMob/UMP 기준으로 교체
- 앱 정보 버전 1.0.10 반영

## 유지
- 기존 고정 Android 서명키를 사용하는 GitHub Secrets 방식
- WebView 화면 구조 및 하단 배너 영역
- 백업/복원
- 커스텀 모달/토스트
- Android 뒤로가기
- Android 16 / API 36
