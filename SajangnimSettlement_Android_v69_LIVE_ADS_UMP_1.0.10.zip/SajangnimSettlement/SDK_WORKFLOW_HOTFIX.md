# GitHub Actions Android SDK hotfix

- Updated `android-actions/setup-android` from v3 to v4.
- Disabled the action's deprecated default `tools` package install with `packages: ''`.
- Installs only `platform-tools`, Android API 36, and Build Tools 36.0.0 via `sdkmanager`.
- App code, versionCode/versionName, production AdMob IDs, UMP integration, and signing-secret names are unchanged.
