package com.sajangnim.settlement;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context newBase) {
        android.content.res.Configuration config =
            new android.content.res.Configuration(newBase.getResources().getConfiguration());
        config.fontScale = 1.0f;
        android.content.Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }


    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final String LIVE_BANNER_AD_UNIT_ID = "ca-app-pub-8303166591303807/4822308146";
    private LinearLayout rootLayout;
    private WebView webView;
    private FrameLayout adContainer;
    private AdView adView;
    private ValueCallback<Uri[]> filePathCallback;
    private ConsentInformation consentInformation;
    private final AtomicBoolean mobileAdsInitialized = new AtomicBoolean(false);
    private volatile boolean mobileAdsReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep the v60 WebView geometry. The only new element is a banner row below it.
        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(Color.WHITE);

        webView = new WebView(this);
        rootLayout.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        adContainer = new FrameLayout(this);
        rootLayout.addView(adContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // v60 reserved the status-bar inset on the WebView itself. Preserve that exact top behavior.
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
            return insets;
        });

        // Reserve only the bottom navigation-bar inset at the root so the ad never sits under it.
        rootLayout.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, 0, 0, insets.getSystemWindowInsetBottom());
            return insets;
        });

        setContentView(rootLayout);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setTextZoom(100);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                updatePrivacyOptionsAvailability();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {

                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }

                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);

                // 일부 Android 파일 앱/제조사 파일 선택기는 .json 파일을
                // application/json이 아니라 text/plain 또는
                // application/octet-stream으로 분류하기도 합니다.
                // 한 MIME 타입으로 제한하면 정상 백업 파일이 목록에서 사라질 수 있어
                // 파일 선택 화면에서는 넓게 허용하고, 실제 JSON 검증은 앱에서 수행합니다.
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                        "application/json",
                        "text/json",
                        "text/plain",
                        "application/octet-stream"
                });

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    // ACTION_OPEN_DOCUMENT를 지원하지 않는 파일 앱 대비
                    try {
                        Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType("*/*");
                        startActivityForResult(fallback, FILE_CHOOSER_REQUEST);
                        return true;
                    } catch (Exception ignored) {
                        MainActivity.this.filePathCallback = null;
                        return false;
                    }
                }
            }
        });

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    2001
            );
        }

        webView.loadUrl("file:///android_asset/index.html");

        // Production ads are requested only after UMP has refreshed the user's consent status.
        requestConsentAndInitializeAds();
    }

    public class AndroidBridge {

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> finish());
        }

        @JavascriptInterface
        public void setAppFontScale(int percent) {
            final int safePercent = Math.max(80, Math.min(130, percent));
            runOnUiThread(() -> {
                if (webView != null) {
                    webView.getSettings().setTextZoom(safePercent);
                }
            });
        }

        @JavascriptInterface
        public void setSystemBarsTheme(boolean dark) {
            runOnUiThread(() -> {
                getWindow().setStatusBarColor(Color.parseColor(dark ? "#111827" : "#24364B"));
                getWindow().setNavigationBarColor(Color.parseColor(dark ? "#111827" : "#FFFFFF"));
                if (rootLayout != null) {
                    rootLayout.setBackgroundColor(Color.parseColor(dark ? "#111827" : "#FFFFFF"));
                }

                View decor = getWindow().getDecorView();
                int flags = decor.getSystemUiVisibility();

                // Keep status-bar icons white in both themes.
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;

                // Bottom navigation icons still follow the selected theme.
                if (dark) {
                    flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                } else {
                    flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }

                decor.setSystemUiVisibility(flags);
            });
        }
        @JavascriptInterface
        public void openAdPrivacyOptions() {
            runOnUiThread(() -> {
                if (consentInformation == null ||
                        consentInformation.getPrivacyOptionsRequirementStatus() !=
                                ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED) {
                    showWebToast("현재 변경할 광고 개인정보 설정이 없습니다.");
                    return;
                }

                UserMessagingPlatform.showPrivacyOptionsForm(
                        MainActivity.this,
                        formError -> {
                            updatePrivacyOptionsAvailability();
                            if (formError != null) {
                                showWebToast("광고 개인정보 설정을 열 수 없습니다.");
                                return;
                            }
                            if (consentInformation.canRequestAds()) {
                                if (mobileAdsReady) {
                                    reloadLiveBanner();
                                } else {
                                    initializeMobileAdsOnce();
                                }
                            } else {
                                clearBanner();
                            }
                        }
                );
            });
        }

        @JavascriptInterface
        public void saveBackup(String json, String fileName) {
            runOnUiThread(() -> {
                try {
                    String safeName = (fileName == null || fileName.trim().isEmpty())
                            ? "사장님정산_백업.json"
                            : fileName;

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentResolver resolver = getContentResolver();
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                        values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (uri == null) throw new Exception("다운로드 파일을 만들 수 없습니다.");

                        try (OutputStream out = resolver.openOutputStream(uri)) {
                            if (out == null) throw new Exception("파일을 열 수 없습니다.");
                            out.write(json.getBytes(StandardCharsets.UTF_8));
                            out.flush();
                        }
                    } else {
                        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                        if (!downloads.exists() && !downloads.mkdirs()) {
                            throw new Exception("다운로드 폴더를 만들 수 없습니다.");
                        }

                        File target = new File(downloads, safeName);
                        try (FileOutputStream out = new FileOutputStream(target)) {
                            out.write(json.getBytes(StandardCharsets.UTF_8));
                            out.flush();
                        }
                    }

                    webView.evaluateJavascript(
                            "if(typeof onNativeBackupSaved==='function'){onNativeBackupSaved();}",
                            null
                    );
                } catch (Exception e) {
                    webView.evaluateJavascript(
                            "if(typeof onNativeBackupFailed==='function'){onNativeBackupFailed();}",
                            null
                    );
                }
            });
        }
    }

    private void requestConsentAndInitializeAds() {
        consentInformation = UserMessagingPlatform.getConsentInformation(this);

        ConsentRequestParameters params = new ConsentRequestParameters.Builder().build();
        consentInformation.requestConsentInfoUpdate(
                this,
                params,
                () -> {
                    updatePrivacyOptionsAvailability();

                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                            MainActivity.this,
                            formError -> {
                                updatePrivacyOptionsAvailability();
                                if (consentInformation.canRequestAds()) {
                                    initializeMobileAdsOnce();
                                }
                            }
                    );

                    // A previous valid consent decision may already allow ads before a form is needed.
                    if (consentInformation.canRequestAds()) {
                        initializeMobileAdsOnce();
                    }
                },
                requestConsentError -> {
                    updatePrivacyOptionsAvailability();
                    // If a previous valid consent decision exists, ads may still be requested.
                    if (consentInformation.canRequestAds()) {
                        initializeMobileAdsOnce();
                    }
                }
        );

        if (consentInformation.canRequestAds()) {
            initializeMobileAdsOnce();
        }
    }

    private void initializeMobileAdsOnce() {
        if (mobileAdsInitialized.getAndSet(true)) return;

        MobileAds.initialize(this, initializationStatus -> {
            mobileAdsReady = true;
            if (adContainer != null) {
                adContainer.post(this::loadLiveBanner);
            }
        });
    }

    private void loadLiveBanner() {
        if (consentInformation == null || !consentInformation.canRequestAds()) return;

        if (adContainer == null || adContainer.getWidth() <= 0) {
            if (adContainer != null) adContainer.post(this::loadLiveBanner);
            return;
        }

        if (adView != null) {
            adView.destroy();
            adView = null;
        }

        float density = getResources().getDisplayMetrics().density;
        int adWidthDp = Math.max(1, (int) (adContainer.getWidth() / density));
        AdSize adSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidthDp);

        adView = new AdView(this);
        adView.setAdUnitId(LIVE_BANNER_AD_UNIT_ID);
        adView.setAdSize(adSize);
        adContainer.removeAllViews();
        adContainer.addView(adView);
        adView.loadAd(new AdRequest.Builder().build());
    }

    private void clearBanner() {
        if (adView != null) {
            adView.destroy();
            adView = null;
        }
        if (adContainer != null) {
            adContainer.removeAllViews();
        }
    }

    private void reloadLiveBanner() {
        if (adView != null) {
            adView.destroy();
            adView = null;
        }
        if (adContainer != null) {
            adContainer.removeAllViews();
            adContainer.post(this::loadLiveBanner);
        }
    }

    private void updatePrivacyOptionsAvailability() {
        if (webView == null) return;

        boolean required = consentInformation != null &&
                consentInformation.getPrivacyOptionsRequirementStatus() ==
                        ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;

        String script = "if(typeof setAdPrivacyOptionsVisible==='function'){" +
                "setAdPrivacyOptionsVisible(" + required + ");}";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private void showWebToast(String message) {
        if (webView == null) return;
        String safe = message.replace("\\", "\\\\").replace("'", "\\'");
        String script = "if(typeof showBackupToast==='function'){showBackupToast('" + safe + "');}";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    @Override
    protected void onPause() {
        if (adView != null) adView.pause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adView != null) adView.resume();
    }

    @Override
    protected void onDestroy() {
        if (adView != null) adView.destroy();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;

            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }

            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return (typeof handleNativeBackInPage==='function' && handleNativeBackInPage()) ? '1' : '0';}catch(e){return '0';}})()",
                value -> {
                    if ("\"1\"".equals(value)) {
                        return;
                    }

                    if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        webView.evaluateJavascript("showExitConfirm()", null);
                    }
                }
        );
    }
}
