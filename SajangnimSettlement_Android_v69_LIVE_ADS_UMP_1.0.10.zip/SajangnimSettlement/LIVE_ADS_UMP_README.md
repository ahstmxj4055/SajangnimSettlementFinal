# 실광고 + UMP 적용 확인

- 앱 ID: `ca-app-pub-8303166591303807~3753679186`
- 배너 광고 단위 ID: `ca-app-pub-8303166591303807/4822308146`
- 광고 요청 전 `ConsentInformation.canRequestAds()` 확인
- UMP consent info는 앱 실행마다 갱신
- 필요한 경우 consent form 자동 표시
- privacy options가 REQUIRED인 경우 앱 내 재설정 버튼 표시

주의: 본인 기기에서 실제 광고를 반복 클릭하지 마세요. 실광고 적용 후에는 노출/레이아웃/앱 기능 위주로 확인하세요.
