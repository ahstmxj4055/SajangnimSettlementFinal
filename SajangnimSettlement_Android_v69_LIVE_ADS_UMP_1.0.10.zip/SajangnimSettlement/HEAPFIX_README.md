# v69 1.0.10 GitHub Actions heap fix

Build log failure fixed:
- Task: :app:mergeDexRelease
- Error: java.lang.OutOfMemoryError: Java heap space

Applied:
- Gradle JVM heap: 4096 MB
- Max metaspace: 1024 MB
- Max workers: 2
- Parallel execution: disabled

No app feature, AdMob ID, UMP setting, signing config, versionCode, or versionName was changed.
