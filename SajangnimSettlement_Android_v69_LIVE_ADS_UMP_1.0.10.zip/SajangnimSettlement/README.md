# 사장님 정산 Android 1.0.10 - 실광고 + UMP

- compileSdk 36
- targetSdk 36 (Android 16)
- minSdk 24
- JDK 17
- Android Gradle Plugin 8.10.1
- Gradle 8.11.1
- Google Mobile Ads SDK 25.4.0
- Google UMP SDK 4.0.0
- AdMob 앱 ID: ca-app-pub-8303166591303807~3753679186
- 하단 배너 광고 단위 ID: ca-app-pub-8303166591303807/4822308146
- 버전: 1.0.10 / versionCode 11

## 이번 버전 변경
- Google 테스트 배너 ID를 실제 `하단 배너 광고` ID로 교체
- 앱 시작 시 UMP 동의 상태를 갱신한 뒤 광고 요청 가능 여부 확인
- 동의가 필요한 경우 UMP 동의 폼 자동 표시
- UMP에서 개인정보 옵션 재진입이 필요한 경우 앱 개인정보처리방침 화면에 `광고 개인정보 설정` 버튼 표시
- 앱 내 개인정보처리방침을 AdMob/UMP 포함 내용으로 변경
- 공개 개인정보처리방침 URL 반영: https://ahstmxj4055.github.io/sajangnim-privacy/
- 기존 WebView UI, 백업/복원, 뒤로가기, 하단 배너 레이아웃 유지

## AdMob에서 별도로 해야 하는 설정
UMP SDK 코드는 포함되어 있지만 실제 동의 폼은 AdMob의 `개인 정보 보호 및 메시지`에서 메시지를 게시해야 표시됩니다.
해당 지역 사용자에게 필요한 메시지를 AdMob에서 생성/게시한 뒤 출시하세요.

## 빌드
GitHub Actions에서 기존 고정 서명키 Secrets를 그대로 사용해 Release APK와 AAB를 만듭니다.
Google Play 업로드에는 AAB를 사용하세요.
