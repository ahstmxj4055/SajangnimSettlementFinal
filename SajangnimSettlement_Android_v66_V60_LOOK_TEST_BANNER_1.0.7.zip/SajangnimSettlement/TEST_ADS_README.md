# v66 V60 LOOK + TEST BANNER

- Base: v60 1.0.3 source
- App UI/CSS: unchanged from v60
- Version: 1.0.7 (versionCode 8)
- Bottom banner: Google dedicated Android adaptive banner test unit
- AdMob app ID: production app ID in manifest
- Test banner unit ID: ca-app-pub-3940256099942544/9214589741
- Do not upload this test-ad build as a production release.
