# v41 코드 정리 보고서

## 기준
- 기준본: v40_RESTORE_PICKER_FIX_FINAL
- 화면/기능 변경 없이 코드 구조만 보수적으로 정리
- 백업/복원 로직은 v40 그대로 유지

## 정리 결과
- style 블록: 2개 → 1개
- script 블록: 2개 → 1개
- 완전히 동일한 CSS rule 제거: 5개
- JavaScript 함수: 78개
- JavaScript 중복 함수: 0개
- HTML 중복 id: 0개
- CSS !important: 250개
- 인라인 style 속성: 26개

## 기능 검증
확인된 핵심 함수:
- 빠른 정산 / 달력 / 오늘 날짜
- 상세 정산
- 직원 관리
- 일일알바
- 백업 저장
- 복원
- 구형 백업 호환
- 테마
- 사용 방법

확인된 데이터 저장 키:
- sajangnim_records
- sajangnim_targets
- sajangnim_detail_records
- sajangnim_employees
- sajangnim_detail_auto
- sajangnim_theme

## 백업/복원
v40에서 정상 확인된 로직을 그대로 유지했습니다.
- 빠른 정산
- 월 목표금액
- 상세 정산
- 사용자 추가 매출/지출
- 직원 선택/일당
- 일일알바
- 직원 목록/기본일당/활성상태
- 상세 반영
- 테마

## 아직 남겨둔 CSS 중복
아래는 제거하지 않았습니다. 일부는 반응형/화면별 override라 무조건 병합하면 화면이 깨질 수 있습니다.
- `.target input`: 7회
- `.summary`: 6회
- `.target`: 6회
- `.target button`: 6회
- `body`: 5회
- `.app`: 5회
- `header`: 5회
- `.sum`: 5회
- `.sum b`: 5회
- `.target .rate`: 5회
- `.card`: 4회
- `.day`: 4회
- `.dp`: 4회
- `textarea`: 4회
- `.target span:first-child`: 4회
- `.monthbar`: 3회
- `.sum small`: 3회
- `.goalremain`: 3회
- `.progress`: 3회
- `.calhead`: 3회

## 다음 단계
v41을 실제 폰에서 먼저 확인한 뒤, 화면이 v40과 동일하게 동작하면 v41을 새 코드 기준본으로 사용할 수 있습니다.

그 다음 디자인 리뉴얼 때는 CSS를 한꺼번에 덧붙이지 말고,
기존 선택자를 화면별로 하나씩 교체하는 방식이 안전합니다.
