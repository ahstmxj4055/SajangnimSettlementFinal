# v37 코드 정리 내용

- 기준: v34_DATE_ALIGN_ONLY_FINAL
- UI/기능 변경 없이 유지하는 것을 우선
- HTML 내 style 태그를 1개로 통합
- HTML 내 script 태그를 1개로 통합
- CSS cascade 순서 유지
- 완전히 동일한 CSS rule만 제거
- 과거 v5/v10/v20 같은 버전 이력 주석 제거
- JavaScript 함수 중복 여부 검사
- JavaScript 문법 검사
- localStorage 데이터 키 검사
- Android API 36 설정 유지
- APK + AAB GitHub Actions 유지

대규모 UI 리디자인은 이 정리판 검증 후 진행하는 것을 권장합니다.
