plugins { id("com.android.application") }

android {
    namespace = "com.sajangnim.settlement"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sajangnim.settlement"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
