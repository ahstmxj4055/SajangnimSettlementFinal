# Sajangnim Settlement 1.0.11

Changes prepared from the production 1.0.10 source:

- versionCode 12 / versionName 1.0.11
- Updated launcher icon assets using the full navy background version
- Enabled R8 minification and resource shrinking for release builds
- Added safe keep rules for WebView @JavascriptInterface bridge methods
- androidx.core 1.18.0
- androidx.activity 1.13.0
- androidx.fragment 1.9.1
- Migrated system bar handling to WindowCompat.enableEdgeToEdge + WindowInsetsCompat
- Removed deprecated getSystemWindowInset*, setStatusBarColor, setNavigationBarColor, and systemUiVisibility usage
- Added explicit status/navigation inset spacer views so WebView and AdMob banner stay clear of system bars
- Removed explicit predictive-back opt-out from the manifest
- AdMob app ID, banner unit ID, UMP flow, package name, backup format, and app data logic unchanged

Before Play upload:
1. Build signed release APK/AAB using the existing GitHub secrets/signing key.
2. Install the APK over 1.0.10 and verify existing records/goal/backup remain.
3. Test light/dark system bars, calendar, settings, backup/restore, and live banner visibility.
4. Upload the AAB only after smoke testing passes.
