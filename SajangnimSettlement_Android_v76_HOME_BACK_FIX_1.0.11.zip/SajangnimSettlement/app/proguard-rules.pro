# Sajangnim Settlement 1.0.11 - R8 rules

# Keep runtime annotations used by WebView JavaScript bridge.
-keepattributes RuntimeVisibleAnnotations,RuntimeInvisibleAnnotations,AnnotationDefault

# JavaScript calls these methods by their exact names.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep the bridge class and its public API stable for the local WebView page.
-keep class com.sajangnim.settlement.MainActivity$AndroidBridge { *; }
