package com.sajangnim.settlement;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context newBase) {
        android.content.res.Configuration config =
            new android.content.res.Configuration(newBase.getResources().getConfiguration());
        config.fontScale = 1.0f;
        android.content.Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }


    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final String LIVE_BANNER_AD_UNIT_ID = "ca-app-pub-8303166591303807/4822308146";
    private LinearLayout rootLayout;
    private WebView webView;
    private FrameLayout adContainer;
    private AdView adView;
    private ValueCallback<Uri[]> filePathCallback;
    private ConsentInformation consentInformation;
    private final AtomicBoolean mobileAdsInitialized = new AtomicBoolean(false);
    private volatile boolean mobileAdsReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Android 15+ edge-to-edge 대응.
        // 기존 1.0.10의 화면 위치는 그대로 유지하고, 시스템 바 영역만
        // 최신 WindowInsets API로 안전하게 확보합니다.
        WindowCompat.enableEdgeToEdge(getWindow());

        // 1.0.10과 동일한 구조: WebView + 하단 광고.
        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(Color.WHITE);

        webView = new WebView(this);
        rootLayout.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        adContainer = new FrameLayout(this);
        rootLayout.addView(adContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(rootLayout);

        // Android 13+ predictive-back 환경에서도 기존 앱의 뒤로가기 동작을 그대로 사용합니다.
        // Activity.onBackPressed()만 의존하면 targetSdk 35+ 기기에서 호출되지 않는 경우가 있어
        // 시스템 Back Dispatcher에 동일한 처리기를 등록합니다.
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    new OnBackInvokedCallback() {
                        @Override
                        public void onBackInvoked() {
                            handleAppBack();
                        }
                    }
            );
        }

        // 상단 inset은 HTML의 env(safe-area-inset-top)가 처리합니다.
        // index.html은 viewport-fit=cover와 safe-area CSS를 이미 사용하므로,
        // 여기서 WebView에 status bar padding을 또 주면 Android 15/16에서
        // 상단 여백이 두 번 적용되어 헤더/요약 카드 위치가 내려가거나 겹칠 수 있습니다.
        // 따라서 WebView 상단 padding은 추가하지 않습니다.

        // 기존 구조대로 하단 내비게이션바는 네이티브 레이아웃에서 보호합니다.
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout, (v, insets) -> {
            int bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;
            v.setPadding(0, 0, 0, bottom);
            return insets;
        });

        ViewCompat.requestApplyInsets(rootLayout);
        applySystemBarsTheme(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setTextZoom(100);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                updatePrivacyOptionsAvailability();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {

                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }

                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);

                // 일부 Android 파일 앱/제조사 파일 선택기는 .json 파일을
                // application/json이 아니라 text/plain 또는
                // application/octet-stream으로 분류하기도 합니다.
                // 한 MIME 타입으로 제한하면 정상 백업 파일이 목록에서 사라질 수 있어
                // 파일 선택 화면에서는 넓게 허용하고, 실제 JSON 검증은 앱에서 수행합니다.
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                        "application/json",
                        "text/json",
                        "text/plain",
                        "application/octet-stream"
                });

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    // ACTION_OPEN_DOCUMENT를 지원하지 않는 파일 앱 대비
                    try {
                        Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType("*/*");
                        startActivityForResult(fallback, FILE_CHOOSER_REQUEST);
                        return true;
                    } catch (Exception ignored) {
                        MainActivity.this.filePathCallback = null;
                        return false;
                    }
                }
            }
        });

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    2001
            );
        }

        webView.loadUrl("file:///android_asset/index.html");

        // Production ads are requested only after UMP has refreshed the user's consent status.
        requestConsentAndInitializeAds();
    }

    private void applySystemBarsTheme(boolean dark) {
        int statusColor = Color.parseColor(dark ? "#111827" : "#24364B");
        int navigationColor = Color.parseColor(dark ? "#111827" : "#FFFFFF");

        if (webView != null) {
            // 상태바 inset 영역이 페이지 상단 색과 자연스럽게 이어지도록 유지
            webView.setBackgroundColor(statusColor);
        }
        if (rootLayout != null) {
            rootLayout.setBackgroundColor(navigationColor);
        }

        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        // Status bar is navy/dark in both themes, so keep icons light.
        controller.setAppearanceLightStatusBars(false);
        // Light theme uses a white navigation area with dark icons.
        controller.setAppearanceLightNavigationBars(!dark);
    }

    public class AndroidBridge {

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> finish());
        }

        @JavascriptInterface
        public void setAppFontScale(int percent) {
            final int safePercent = Math.max(80, Math.min(130, percent));
            runOnUiThread(() -> {
                if (webView != null) {
                    webView.getSettings().setTextZoom(safePercent);
                }
            });
        }

        @JavascriptInterface
        public void setSystemBarsTheme(boolean dark) {
            runOnUiThread(() -> applySystemBarsTheme(dark));
        }
        @JavascriptInterface
        public void openAdPrivacyOptions() {
            runOnUiThread(() -> {
                if (consentInformation == null ||
                        consentInformation.getPrivacyOptionsRequirementStatus() !=
                                ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED) {
                    showWebToast("현재 변경할 광고 개인정보 설정이 없습니다.");
                    return;
                }

                UserMessagingPlatform.showPrivacyOptionsForm(
                        MainActivity.this,
                        formError -> {
                            updatePrivacyOptionsAvailability();
                            if (formError != null) {
                                showWebToast("광고 개인정보 설정을 열 수 없습니다.");
                                return;
                            }
                            if (consentInformation.canRequestAds()) {
                                if (mobileAdsReady) {
                                    reloadLiveBanner();
                                } else {
                                    initializeMobileAdsOnce();
                                }
                            } else {
                                clearBanner();
                            }
                        }
                );
            });
        }

        @JavascriptInterface
        public void saveBackup(String json, String fileName) {
            runOnUiThread(() -> {
                try {
                    String safeName = (fileName == null || fileName.trim().isEmpty())
                            ? "사장님정산_백업.json"
                            : fileName;

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentResolver resolver = getContentResolver();
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                        values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (uri == null) throw new Exception("다운로드 파일을 만들 수 없습니다.");

                        try (OutputStream out = resolver.openOutputStream(uri)) {
                            if (out == null) throw new Exception("파일을 열 수 없습니다.");
                            out.write(json.getBytes(StandardCharsets.UTF_8));
                            out.flush();
                        }
                    } else {
                        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                        if (!downloads.exists() && !downloads.mkdirs()) {
                            throw new Exception("다운로드 폴더를 만들 수 없습니다.");
                        }

                        File target = new File(downloads, safeName);
                        try (FileOutputStream out = new FileOutputStream(target)) {
                            out.write(json.getBytes(StandardCharsets.UTF_8));
                            out.flush();
                        }
                    }

                    webView.evaluateJavascript(
                            "if(typeof onNativeBackupSaved==='function'){onNativeBackupSaved();}",
                            null
                    );
                } catch (Exception e) {
                    webView.evaluateJavascript(
                            "if(typeof onNativeBackupFailed==='function'){onNativeBackupFailed();}",
                            null
                    );
                }
            });
        }
    }

    private void requestConsentAndInitializeAds() {
        consentInformation = UserMessagingPlatform.getConsentInformation(this);

        ConsentRequestParameters params = new ConsentRequestParameters.Builder().build();
        consentInformation.requestConsentInfoUpdate(
                this,
                params,
                () -> {
                    updatePrivacyOptionsAvailability();

                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                            MainActivity.this,
                            formError -> {
                                updatePrivacyOptionsAvailability();
                                if (consentInformation.canRequestAds()) {
                                    initializeMobileAdsOnce();
                                }
                            }
                    );

                    // A previous valid consent decision may already allow ads before a form is needed.
                    if (consentInformation.canRequestAds()) {
                        initializeMobileAdsOnce();
                    }
                },
                requestConsentError -> {
                    updatePrivacyOptionsAvailability();
                    // If a previous valid consent decision exists, ads may still be requested.
                    if (consentInformation.canRequestAds()) {
                        initializeMobileAdsOnce();
                    }
                }
        );

        if (consentInformation.canRequestAds()) {
            initializeMobileAdsOnce();
        }
    }

    private void initializeMobileAdsOnce() {
        if (mobileAdsInitialized.getAndSet(true)) return;

        MobileAds.initialize(this, initializationStatus -> {
            mobileAdsReady = true;
            if (adContainer != null) {
                adContainer.post(this::loadLiveBanner);
            }
        });
    }

    private void loadLiveBanner() {
        if (consentInformation == null || !consentInformation.canRequestAds()) return;

        if (adContainer == null || adContainer.getWidth() <= 0) {
            if (adContainer != null) adContainer.post(this::loadLiveBanner);
            return;
        }

        if (adView != null) {
            adView.destroy();
            adView = null;
        }

        float density = getResources().getDisplayMetrics().density;
        int adWidthDp = Math.max(1, (int) (adContainer.getWidth() / density));
        AdSize adSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidthDp);

        adView = new AdView(this);
        adView.setAdUnitId(LIVE_BANNER_AD_UNIT_ID);
        adView.setAdSize(adSize);
        adContainer.removeAllViews();
        adContainer.addView(adView);
        adView.loadAd(new AdRequest.Builder().build());
    }

    private void clearBanner() {
        if (adView != null) {
            adView.destroy();
            adView = null;
        }
        if (adContainer != null) {
            adContainer.removeAllViews();
        }
    }

    private void reloadLiveBanner() {
        if (adView != null) {
            adView.destroy();
            adView = null;
        }
        if (adContainer != null) {
            adContainer.removeAllViews();
            adContainer.post(this::loadLiveBanner);
        }
    }

    private void updatePrivacyOptionsAvailability() {
        if (webView == null) return;

        boolean required = consentInformation != null &&
                consentInformation.getPrivacyOptionsRequirementStatus() ==
                        ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;

        String script = "if(typeof setAdPrivacyOptionsVisible==='function'){" +
                "setAdPrivacyOptionsVisible(" + required + ");}";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private void showWebToast(String message) {
        if (webView == null) return;
        String safe = message.replace("\\", "\\\\").replace("'", "\\'");
        String script = "if(typeof showBackupToast==='function'){showBackupToast('" + safe + "');}";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    @Override
    protected void onPause() {
        if (adView != null) adView.pause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adView != null) adView.resume();
    }

    @Override
    protected void onDestroy() {
        if (adView != null) adView.destroy();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;

            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }

            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    private void handleAppBack() {
        if (webView == null) {
            finish();
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return (typeof handleNativeBackInPage==='function' && handleNativeBackInPage()) ? '1' : '0';}catch(e){return '0';}})()",
                value -> {
                    if ("\"1\"".equals(value)) {
                        return;
                    }

                    // 앱의 화면 전환은 History API(pushState)를 사용하므로
                    // WebView 히스토리가 있으면 이전 화면으로 복귀합니다.
                    if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        webView.evaluateJavascript("showExitConfirm()", null);
                    }
                }
        );
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Android 12 이하용. Android 13+는 OnBackInvokedDispatcher가 호출합니다.
        if (Build.VERSION.SDK_INT < 33) {
            handleAppBack();
        } else {
            handleAppBack();
        }
    }
}
