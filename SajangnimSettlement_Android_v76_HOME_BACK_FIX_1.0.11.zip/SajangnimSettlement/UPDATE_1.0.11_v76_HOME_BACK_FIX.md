# v76 home/back fix

Confirmed issues in v75:
1. Home fixed header stayed at 96px while safe-area padding was added inside it.
   Result: title/subtitle overflowed the fixed header and overlapped summary cards.
2. Hardware/system Back relied on Activity.onBackPressed().
   On Android 13+ / targetSdk 35+ the modern back dispatcher can bypass that legacy callback.

v76 fixes:
- Keep edge-to-edge and current WindowInsets compatibility work.
- Fixed home header total height = 96px + status-bar safe area.
- App content top offset matches the same value.
- Existing home/card/calendar HTML positions otherwise untouched.
- Register OnBackInvokedDispatcher callback on Android 13+.
- Keep existing WebView History API / exit confirmation behavior.
- AD_ID, R8, AndroidX upgrades, ads/UMP all preserved.
- versionCode 16
- versionName 1.0.11
