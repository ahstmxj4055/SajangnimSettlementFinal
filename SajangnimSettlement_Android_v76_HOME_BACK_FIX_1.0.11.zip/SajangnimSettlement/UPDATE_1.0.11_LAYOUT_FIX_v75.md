# 1.0.11 verified layout fix (v75)

검증 결과 v74에는 Android 15/16에서 상단 inset이 이중 적용될 가능성이 있었습니다.

기존 1.0.10:
- 네이티브 WebView status-bar inset
- edge-to-edge가 아니어서 CSS env(safe-area-inset-top)는 사실상 추가값이 거의 없음

v74:
- edge-to-edge 활성화
- WebView native top inset 추가
- HTML도 env(safe-area-inset-top) 추가
=> 상단 inset 중복 가능

v75:
- WindowCompat.enableEdgeToEdge() 유지
- HTML의 viewport-fit=cover + env(safe-area-inset-top)에 상단 처리를 맡김
- WebView native top padding 제거
- 기존 index.html/UI는 수정하지 않음
- 하단 광고 보호용 navigation-bar 처리 유지
- AD_ID / R8 / AndroidX / targetSdk 36 유지
- versionCode 15
- versionName 1.0.11
