# 1.0.11 layout-position fix (v74)

- 기존 1.0.10 WebView/광고 배치 구조 복원
- 별도 status/navigation spacer 제거
- Android 15/16 대응은 WindowInsetsCompat로 유지
- WebView 상단에 status bar inset만 적용
- rootLayout 하단에 navigation bar inset만 적용
- 기존 화면 요소 위치/간격은 index.html을 건드리지 않음
- AD_ID, R8, AndroidX 업데이트는 그대로 유지
- versionCode: 14
- versionName: 1.0.11
