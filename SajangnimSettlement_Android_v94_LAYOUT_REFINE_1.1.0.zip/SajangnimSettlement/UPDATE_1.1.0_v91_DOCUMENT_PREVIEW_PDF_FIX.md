# v91 document preview / PDF fix

Fixes:
- Blank document preview on Android WebView.
- Preview no longer depends on DOM ids becoming JavaScript global variables.
- Preview rendering now explicitly resolves #documentPrintPaper and catches rendering failures.
- PDF/print now uses a dedicated native WebView containing only the generated document HTML.
- Keeps the old printCurrentPage fallback.
- versionName 1.1.0
- versionCode 23

The system print screen should open, where Android supports Save as PDF / printer output.
