# 1.1.0 Documents + Excel

- 견적서 작성/저장/수정/삭제
- 거래명세서 작성/견적서 변환
- 공급자 사업자 정보 저장
- 품목/수량/단가/부가세 자동 계산
- Android 인쇄 프레임워크를 이용한 PDF 저장/인쇄
- 실제 XLSX 생성: 월간요약 / 일별정산 / 직원급여 3개 시트
- 문서 데이터 백업/복원 schemaVersion 7
- versionName 1.1.0 / versionCode 22

내부 테스트에서 PDF 저장, XLSX 열기, 백업 복원을 실제 기기로 최종 확인하세요.
