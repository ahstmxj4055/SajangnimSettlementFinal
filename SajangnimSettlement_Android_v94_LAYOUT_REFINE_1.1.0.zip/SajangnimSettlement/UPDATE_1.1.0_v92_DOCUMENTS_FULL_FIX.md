사장님 정산 v92 문서 기능 전체 수정 점검

원인:
- v90/v91 문서 코드가 HTML id를 JavaScript 전역변수처럼 사용했습니다.
- Android WebView에서는 이 방식이 보장되지 않아 품목 입력 후 updateDocumentTotals()에서 오류가 발생할 수 있었습니다.
- 같은 원인으로 currentDocumentDraft()가 실패해 미리보기 데이터 생성도 실패했습니다.
- 사업자정보 저장과 월간 Excel 화면에도 같은 패턴이 남아 있었습니다.

v92 수정:
- 문서/사업자/Excel 관련 DOM 접근을 전부 document.getElementById 기반 docEl()로 변경
- 수량/단가 변경 즉시 공급가액/부가세/합계 갱신
- 미리보기 생성 시 현재 입력값을 안전하게 복사해 렌더링
- 미리보기 즉시 렌더 + 60ms 재렌더로 Android WebView 화면전환 타이밍 보강
- v91의 전용 PDF WebView 출력 유지
- 사업자정보 저장의 동일 오류 수정
- 월간 Excel 월선택/요약의 동일 오류 수정
- versionName 1.1.0 / versionCode 24

계산 검증:
- 10 × 30,000원 / 부가세 포함: 공급가액 272,727원, 부가세 27,273원, 합계 300,000원
- 10 × 30,000원 / 부가세 별도: 공급가액 300,000원, 부가세 30,000원, 합계 330,000원

암묵적 DOM 전역 참조 잔여: 없음
JavaScript syntax check: 통과
