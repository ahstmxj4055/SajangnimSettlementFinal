v103: 3 equal-width buttons, direct PDF Downloads save, PNG Downloads save, removed print labels and notice. Android runtime verification required.
