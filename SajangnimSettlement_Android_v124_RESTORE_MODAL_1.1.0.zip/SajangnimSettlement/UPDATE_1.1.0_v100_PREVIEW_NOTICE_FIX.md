# v100 Preview + Notice Fix

- 문서 미리보기 데이터가 화면 전환 중 사라지는 문제 보강
- preview draft를 window + sessionStorage + localStorage fallback으로 보존
- 미리보기 페이지 진입 시 자동 재렌더
- PDF 저장/인쇄도 같은 preview draft를 사용
- 공지사항에 2026.10.14 견적서/거래명세서/월간 Excel 기능 추가 공지 삽입
- versionName 1.1.0
- versionCode 32
- JavaScript syntax: PASS
