# v102 PDF + Image Save

- 문서 미리보기에서 PDF 저장/인쇄 + 이미지 저장(PNG) 두 방식 제공
- 이미지 저장은 문서 전용 WebView를 PNG로 렌더링해 Downloads 폴더에 저장
- PDF 출력 방식은 기존 시스템 인쇄/PDF 저장 유지
- 미리보기 버튼 문구를 '미리보기'로 단순화
- 2026.10.14 공지의 문서 기능 설명에 이미지 저장 추가
- versionName 1.1.0
- versionCode 34
- JS syntax: PASS
- checks: {'image_button': True, 'native_bridge_call': True, 'java_bridge': True, 'bitmap_save': True, 'pdf_kept': True, 'notice_updated': True, 'version_34': True}
