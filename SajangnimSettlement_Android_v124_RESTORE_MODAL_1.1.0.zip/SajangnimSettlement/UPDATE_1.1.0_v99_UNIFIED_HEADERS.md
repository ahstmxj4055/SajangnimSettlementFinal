# v99 Unified Headers

- 설정 화면 포함 모든 서브화면 상단바를 홈 상단바 기준으로 통일
- 높이: 72px + safe-area
- 좌우 패딩/뒤로가기 위치도 홈과 동일 기준
- settings/theme/appInfo 등에 남아 있던 오래된 top:48px / top:58px 규칙을 최종 override
- 서브화면 제목은 absolute가 아닌 중앙 정렬 flex 기준으로 변경
- 기존 문서/엑셀/계산/PDF 기능 유지
- versionName 1.1.0
- versionCode 31
- JavaScript syntax: PASS
