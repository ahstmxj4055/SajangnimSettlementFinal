# v96 Verified Layout

Verified against actual v95 HTML/CSS structure.

Fixes:
- Home document/report shortcuts: equal two columns, compact 84px height.
- Document hub info-wrap starts 8px below sticky header.
- Quote / statement create buttons are forced to equal two columns.
- Explicitly overrides the legacy rule that made the last document button span both columns.
- Monthly Excel info-wrap starts 8px below sticky header.
- All v92/v93 document calculations, preview, PDF and Excel logic preserved.
- versionName 1.1.0
- versionCode 28

Static checks: {'home_two_columns': True, 'doc_last_child_override': True, 'doc_top_gap': True, 'excel_top_gap': True, 'two_doc_buttons': True}
JavaScript syntax: PASS

