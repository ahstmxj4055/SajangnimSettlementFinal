# v97 Compact UI

- 상단바 높이는 현재 안정값 그대로 유지
- 홈 문서·리포트 단축 버튼 높이 70px
- 견적서/거래명세서 만들기 버튼 높이 76px
- 월간 Excel 파일 만들기 버튼 높이 64px
- 월간 Excel 카드 내부 세로 여백 축소
- 기능 로직은 v96 그대로 유지
- versionName 1.1.0
- versionCode 29
