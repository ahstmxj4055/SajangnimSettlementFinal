사장님 정산 v101 원인 점검 및 수정

실제 원인:
- 신규 문서/엑셀 코드가 money(...) 함수를 사용하고 있었지만 money 함수 자체가 정의되어 있지 않았습니다.
- 이 때문에:
  1) 견적서/거래명세서 합계 갱신이 ReferenceError로 중단되어 0원으로 남음
  2) 미리보기 HTML 생성도 money(...)에서 중단되어 '미리보기를 불러오지 못했습니다' 표시
  3) 최근 문서 금액 표시와 월간 엑셀 요약도 같은 오류 가능
- 이전 버전의 JavaScript 문법 검사는 '정의되지 않은 함수 호출'을 문법 오류로 잡지 못해서 통과한 것입니다.

v101 수정:
- money() 금액 포맷 함수 실제 정의 추가
- 미리보기 draft 3중 보존 유지
- documentpreview 페이지 진입 시 renderAppPageFromHistory에서도 자동 렌더
- PDF/인쇄도 getPreviewDraft() 사용
- 공지사항 실제 notice-list-card 내부 최상단에 2026.10.14 업데이트 공지 삽입
- versionName 1.1.0 / versionCode 33

계산 검증:
- 10 × 30,000원 / 부가세 별도 = 공급가액 300,000원, 부가세 30,000원, 합계 330,000원
- 10 × 30,000원 / 부가세 포함 = 공급가액 272,727원, 부가세 27,273원, 합계 300,000원

정적 검증:
{'money_defined': True, 'money_calls_present': True, 'preview_persisted': True, 'preview_route_render': True, 'notice_actual_location': True, 'notice_date': True, 'version_code_33': True}

JavaScript syntax: PASS

