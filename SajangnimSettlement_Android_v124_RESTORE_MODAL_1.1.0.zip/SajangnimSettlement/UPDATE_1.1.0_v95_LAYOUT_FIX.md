# v95 layout correction

User screenshot-based corrections:
- 홈 문서·리포트 카드 전체 높이 축소
- 홈의 두 버튼 높이 96px로 통일
- 문서·리포트 페이지 상단바 아래 과도한 여백 제거
- 견적서 만들기 / 거래명세서 만들기 2열 배치 유지, 높이 110px 통일
- 월간 엑셀 페이지 상단바 아래 여백 축소
- 기존 v94 기능 유지
- versionName 1.1.0
- versionCode 27
