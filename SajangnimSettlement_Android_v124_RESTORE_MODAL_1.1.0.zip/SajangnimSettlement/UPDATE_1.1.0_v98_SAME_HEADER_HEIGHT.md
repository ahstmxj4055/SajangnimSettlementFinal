# v98 Same Header Height

- 문서·리포트, 월간 엑셀, 문서 작성/미리보기, 설정 화면 상단바를 홈 상단바와 동일한 높이로 통일
- 기준: 72px + Android safe-area
- 제목/뒤로가기 버튼 수직 정렬도 동일 기준 적용
- 헤더 아래 콘텐츠 간격은 8px 유지
- v97 컴팩트 버튼 높이 유지
- versionName 1.1.0
- versionCode 30
