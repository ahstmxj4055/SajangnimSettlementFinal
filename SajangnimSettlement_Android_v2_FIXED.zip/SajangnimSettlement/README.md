# 사장님 정산 Android

현재 v7 웹앱을 Android WebView 앱으로 감싼 테스트 프로젝트입니다.

## GitHub에서 APK 만들기
1. 이 프로젝트 전체를 GitHub 저장소의 main 브랜치에 업로드합니다.
2. Actions 탭에서 `Android APK Build`를 실행합니다. push 시에도 자동 실행됩니다.
3. 빌드가 성공하면 Artifacts의 `SajangnimSettlement-debug-apk`를 다운로드합니다.
4. ZIP을 풀고 `app-debug.apk`를 갤럭시에 설치합니다.

※ 이 APK는 테스트용 debug APK입니다. Play 스토어 출시는 서명된 AAB 및 추가 출시 설정이 필요합니다.


## v2 build fix
GitHub Actions build no longer depends on a missing gradlew file. It uses Gradle 8.7 directly.
